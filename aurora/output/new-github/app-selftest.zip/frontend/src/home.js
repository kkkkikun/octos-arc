"use strict";

// Workspace home: public organizations for discovery, plus the signed-in
// user's own organizations. The username itself is rendered by nav.js.
(function () {
  const main = document.getElementById("main");

  whenNavReady(async () => {
    const user = window.__user;
    main.replaceChildren();
    main.append(el("h1", { text: "GitHub" }));
    main.append(el("p", { class: "subtitle", text: "A simplified GitHub collaboration platform." }));

    if (user) {
      const tools = el("div", { class: "toolrow" }, [
        el("a", { class: "btn btn-primary", href: "/new-repository", text: "New repository" }),
      ]);
      main.append(tools);
      const mineRepos = await api.get("/api/repos/mine");
      if (mineRepos.ok && mineRepos.data.repos.length) {
        const section = el("section", {});
        section.append(el("h2", { text: "Your repositories" }));
        for (const repo of mineRepos.data.repos) {
          const row = el("div", { class: "repo-row" });
          row.append(el("a", { href: "/repo/" + encodeURIComponent(repo.name), text: repo.name }));
          row.append(el("span", { class: "desc", text: repo.description || "" }));
          row.append(el("span", { class: "badge", text: repo.visibility === "private" ? "Private" : "Public" }));
          section.append(row);
        }
        main.append(section);
      }
      const mine = await api.get("/api/orgs/mine");
      if (mine.ok && mine.data.orgs.length) {
        const section = el("section", {});
        section.append(el("h2", { text: "Organizations" }));
        for (const org of mine.data.orgs) {
          section.append(orgRow(org));
        }
        main.append(section);
      }
    }

    const pub = await api.get("/api/orgs/public");
    if (pub.ok) {
      const section = el("section", {});
      section.append(el("h2", { text: "Public organizations" }));
      for (const org of pub.data.orgs) {
        section.append(orgRow(org));
      }
      main.append(section);
    }

    // Repositories listed directly on the workspace so any repository name
    // is an immediately visible navigation target: visitors see the public
    // ones, signed-in users see everything they can read.
    const repos = await api.get("/api/repos/public");
    if (repos.ok && repos.data.repos.length) {
      const section = el("section", {});
      section.append(el("h2", { text: user ? "Repositories" : "Public repositories" }));
      for (const repo of repos.data.repos) {
        const row = el("div", { class: "repo-row" });
        row.append(el("a", { href: "/repo/" + encodeURIComponent(repo.name), text: repo.name }));
        row.append(el("span", { class: "desc", text: repo.description || "" }));
        row.append(el("span", { class: "badge", text: repo.orgName }));
        row.append(el("span", { class: "badge", text: repo.visibility === "private" ? "Private" : "Public" }));
        section.append(row);
      }
      main.append(section);
    }

    function orgRow(org) {
      const row = el("div", { class: "repo-row" });
      row.append(el("a", { href: "/org/" + encodeURIComponent(org.slug), text: org.name }));
      row.append(el("span", { class: "badge", text: "Organization" }));
      return row;
    }
  });
})();
