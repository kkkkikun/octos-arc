"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DIST_DIR = path.resolve(__dirname, "..", "frontend", "dist");
const PORT = Number(process.env.PORT || 43100);

// --- Persistence pattern ---
// State lives in store.json next to this file; the shipped initial state
// lives in seed-default.json. Write atomically (tmp+rename) so a mid-write
// kill never corrupts the store, and reseed on missing/corrupt store so the
// app always boots.
const STORE_FILE = path.join(__dirname, "store.json");
const SEED_FILE = path.join(__dirname, "seed-default.json");

function saveStore(store) {
  const tmp = STORE_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(store));
  fs.renameSync(tmp, STORE_FILE);
}

function loadStore() {
  try {
    const data = JSON.parse(fs.readFileSync(STORE_FILE, "utf8"));
    if (data && typeof data === "object") return data;
  } catch (err) { /* corrupt or missing: reseed */ }
  const seeded = JSON.parse(fs.readFileSync(SEED_FILE, "utf8"));
  saveStore(seeded);
  return seeded;
}

const MIME_TYPES = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
};

function send(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "text/plain; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}

function sendHtml(res, status, html) {
  res.writeHead(status, {
    "Content-Type": "text/html; charset=utf-8",
    "Content-Length": Buffer.byteLength(html),
  });
  res.end(html);
}

function serveNext(req, res, rels, i) {
  if (i >= rels.length) {
    send(res, 404, "not found\n");
    return;
  }
  const file = path.normalize(path.join(DIST_DIR, rels[i]));
  if (file !== DIST_DIR && !file.startsWith(DIST_DIR + path.sep)) {
    send(res, 404, "not found\n");
    return;
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      serveNext(req, res, rels, i + 1);
      return;
    }
    const type = MIME_TYPES[path.extname(file).toLowerCase()] || "application/octet-stream";
    res.writeHead(200, { "Content-Type": type, "Content-Length": data.length });
    res.end(req.method === "HEAD" ? undefined : data);
  });
}

// --- Validation (REQ-1-1-1) ---
function validateUsername(u) {
  if (typeof u !== "string") return false;
  if (u.length < 1 || u.length > 39) return false;
  return /^[a-z0-9]+(-[a-z0-9]+)*$/.test(u);
}

function validateEmail(e) {
  if (typeof e !== "string") return false;
  const email = e.trim();
  if (email.length > 254) return false;
  const at = email.indexOf("@");
  if (at < 1) return false;
  if (email.indexOf("@", at + 1) !== -1) return false;
  const domain = email.slice(at + 1);
  if (!domain.includes(".")) return false;
  const labels = domain.split(".");
  if (labels.some((l) => l.length === 0)) return false;
  return true;
}

function validatePassword(p) {
  if (typeof p !== "string") return false;
  if (p.length < 12 || p.length > 128) return false;
  if (/\s/.test(p)) return false;
  if (!/[A-Z]/.test(p)) return false;
  if (!/[a-z]/.test(p)) return false;
  if (!/[0-9]/.test(p)) return false;
  if (!/[^A-Za-z0-9]/.test(p)) return false;
  return true;
}

// --- helpers ---
function parseCookies(req) {
  const header = req.headers.cookie || "";
  const cookies = {};
  header.split(";").forEach((part) => {
    const idx = part.indexOf("=");
    if (idx > -1) {
      const k = part.slice(0, idx).trim();
      const v = part.slice(idx + 1).trim();
      try { cookies[k] = decodeURIComponent(v); } catch { cookies[k] = v; }
    }
  });
  return cookies;
}

function parseUrlEncoded(body) {
  const params = {};
  body.split("&").forEach((pair) => {
    if (!pair) return;
    const idx = pair.indexOf("=");
    const k = decodeURIComponent(pair.slice(0, idx));
    const v = decodeURIComponent(pair.slice(idx + 1));
    params[k] = v;
  });
  return params;
}

function readBody(req, cb) {
  let body = "";
  req.on("data", (chunk) => {
    body += chunk;
    if (body.length > 1e6) req.destroy();
  });
  req.on("end", () => cb(body));
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// --- rendered pages (server-side re-render on failed POST) ---
function renderSigninPage(error, login) {
  const errHtml = error
    ? `<div class="error">${escapeHtml(error)}</div>`
    : `<div class="error"></div>`;
  const lg = escapeHtml(login || "");
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sign in to GitHub</title>
  <style>
    [hidden] { display: none !important; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; margin: 0; background: #f6f8fa; }
    .card { max-width: 340px; margin: 80px auto; background: #fff; border: 1px solid #d0d7de; border-radius: 6px; padding: 20px; }
    h1 { font-size: 20px; }
    label { display: block; margin-bottom: 4px; font-weight: 600; font-size: 14px; }
    input { width: 100%; box-sizing: border-box; padding: 8px; margin-bottom: 12px; border: 1px solid #d0d7de; border-radius: 6px; }
    button { width: 100%; padding: 8px; background: #1f883d; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
    .error { color: #cf222e; font-size: 12px; margin-bottom: 8px; }
    .link-row { text-align: center; margin-top: 16px; }
    a { color: #0969da; text-decoration: none; }
  </style>
</head>
<body>
  <main class="card">
    <h1>Sign in to GitHub</h1>
    <form method="post" action="/signin">
      <label for="login">Username or email</label>
      <input id="login" name="login" type="text" aria-label="Username or email" autocomplete="username" value="${lg}" />
      <label for="password">Password</label>
      <input id="password" name="password" type="password" aria-label="Password" autocomplete="current-password" />
      ${errHtml}
      <button type="submit">Sign in</button>
    </form>
    <div class="link-row">
      <a href="/recover">Forgot password</a>
    </div>
    <div class="link-row">
      <a href="/register">Create an account</a>
    </div>
  </main>
</body>
</html>`;
}

function renderRegisterPage(errors, username, email) {
  errors = errors || {};
  const e = (k) =>
    errors[k]
      ? `<div class="field-error">${escapeHtml(errors[k])}</div>`
      : `<div class="field-error"></div>`;
  const u = escapeHtml(username || "");
  const em = escapeHtml(email || "");
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Create your account</title>
  <style>
    [hidden] { display: none !important; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; margin: 0; background: #f6f8fa; }
    .card { max-width: 340px; margin: 40px auto; background: #fff; border: 1px solid #d0d7de; border-radius: 6px; padding: 20px; }
    h1 { font-size: 20px; }
    label { display: block; margin-bottom: 4px; font-weight: 600; font-size: 14px; }
    input[type=text], input[type=email], input[type=password] { width: 100%; box-sizing: border-box; padding: 8px; margin-bottom: 4px; border: 1px solid #d0d7de; border-radius: 6px; }
    .field-error { color: #cf222e; font-size: 12px; margin-bottom: 12px; min-height: 14px; }
    .checkbox-row { display: flex; align-items: flex-start; gap: 8px; margin: 8px 0; }
    .checkbox-row input { margin-top: 2px; }
    button { width: 100%; padding: 8px; background: #1f883d; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
  </style>
</head>
<body>
  <main class="card">
    <h1>Sign up for GitHub</h1>
    <form method="post" action="/register" novalidate>
      <label for="username">Username</label>
      <input id="username" name="username" type="text" aria-label="Username" autocomplete="username" value="${u}" />
      ${e("username")}
      <label for="email">Email</label>
      <input id="email" name="email" type="email" aria-label="Email" autocomplete="email" value="${em}" />
      ${e("email")}
      <label for="password">Password</label>
      <input id="password" name="password" type="password" aria-label="Password" autocomplete="new-password" />
      ${e("password")}
      <label for="confirm">Confirm password</label>
      <input id="confirm" name="confirm" type="password" aria-label="Confirm password" autocomplete="new-password" />
      <div class="field-error"></div>
      <div class="checkbox-row">
        <input id="terms" name="terms" type="checkbox" aria-label="Agree to the terms" />
        <label for="terms">Agree to the terms</label>
      </div>
      ${e("terms")}
      <button type="submit">Create account</button>
    </form>
  </main>
</body>
</html>`;
}

// --- Recover account (REQ-1-1-3) ---
function renderResetStepPage(email, error) {
  const errHtml = error
    ? `<div class="error">${escapeHtml(error)}</div>`
    : `<div class="error"></div>`;
  const em = escapeHtml(email || "");
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Reset your password</title>
  <style>
    [hidden] { display: none !important; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; margin: 0; background: #f6f8fa; }
    .card { max-width: 340px; margin: 80px auto; background: #fff; border: 1px solid #d0d7de; border-radius: 6px; padding: 20px; }
    h1 { font-size: 20px; }
    label { display: block; margin-bottom: 4px; font-weight: 600; font-size: 14px; }
    input { width: 100%; box-sizing: border-box; padding: 8px; margin-bottom: 12px; border: 1px solid #d0d7de; border-radius: 6px; }
    button { width: 100%; padding: 8px; background: #1f883d; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
    .error { color: #cf222e; font-size: 12px; margin-bottom: 8px; }
    .code { font-size: 24px; font-weight: 600; text-align: center; margin: 12px 0; }
    .link-row { text-align: center; margin-top: 16px; }
    a { color: #0969da; text-decoration: none; }
  </style>
</head>
<body>
  <main class="card">
    <h1>Reset your password</h1>
    <p>Your verification code is:</p>
    <div class="code">123456</div>
    <form method="post" action="/recover/reset">
      <input type="hidden" name="email" value="${em}" />
      <label for="code">Verification code</label>
      <input id="code" name="code" type="text" aria-label="Verification code" autocomplete="one-time-code" />
      <label for="newPassword">New password</label>
      <input id="newPassword" name="newPassword" type="password" aria-label="New password" autocomplete="new-password" />
      <label for="confirm">Confirm password</label>
      <input id="confirm" name="confirm" type="password" aria-label="Confirm password" autocomplete="new-password" />
      ${errHtml}
      <button type="submit">Reset password</button>
    </form>
    <div class="link-row">
      <a href="/signin">Back to sign in</a>
    </div>
  </main>
</body>
</html>`;
}

function renderResetSuccessPage() {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Password updated</title>
  <style>
    [hidden] { display: none !important; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; margin: 0; background: #f6f8fa; }
    .card { max-width: 340px; margin: 80px auto; background: #fff; border: 1px solid #d0d7de; border-radius: 6px; padding: 20px; }
    h1 { font-size: 20px; }
    .link-row { text-align: center; margin-top: 16px; }
    a { color: #0969da; text-decoration: none; }
  </style>
</head>
<body>
  <main class="card">
    <h1>Password updated</h1>
    <p>Your password has been updated successfully.</p>
    <div class="link-row">
      <a href="/signin">Sign in</a>
    </div>
  </main>
</body>
</html>`;
}

function renderAccessDeniedPage() {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Access denied</title>
  <style>
    [hidden] { display: none !important; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; margin: 0; background: #f6f8fa; }
    .card { max-width: 340px; margin: 80px auto; background: #fff; border: 1px solid #d0d7de; border-radius: 6px; padding: 20px; }
    h1 { font-size: 20px; }
    .link-row { text-align: center; margin-top: 16px; }
    a { color: #0969da; text-decoration: none; }
  </style>
</head>
<body>
  <main class="card">
    <h1>Access denied</h1>
    <p>You do not have access to this repository.</p>
    <div class="link-row">
      <a href="/organizations">Your organizations</a>
    </div>
  </main>
</body>
</html>`;
}

function handleRecoverPost(req, res, body) {
  const params = parseUrlEncoded(body);
  const email = params.email || "";
  // Both registered verified emails and unknown emails reach the same reset
  // step and display the fixed verification code without email delivery.
  sendHtml(res, 200, renderResetStepPage(email, null));
}

function handleRecoverReset(req, res, body) {
  const params = parseUrlEncoded(body);
  const email = params.email || "";
  const code = params.code || "";
  const newPassword = params.newPassword || "";
  const confirm = params.confirm || "";

  if (code !== "123456") {
    sendHtml(res, 200, renderResetStepPage(email, "Verification code is invalid"));
    return;
  }

  if (!validatePassword(newPassword) || newPassword !== confirm) {
    sendHtml(res, 200, renderResetStepPage(email, "Password requirements are not satisfied"));
    return;
  }

  const store = loadStore();
  const account = Object.values(store.accounts).find(
    (a) => a.email === email.trim()
  );
  if (account) {
    account.password = newPassword;
    saveStore(store);
  }
  sendHtml(res, 200, renderResetSuccessPage());
}

// --- Change account password (REQ-1-3) ---
function handlePasswordChange(req, res, body) {
  let params;
  try { params = JSON.parse(body || "{}"); } catch { params = {}; }
  const currentPassword = params.currentPassword || "";
  const newPassword = params.newPassword || "";
  const confirmPassword = params.confirmPassword || "";

  const cookies = parseCookies(req);
  const token = cookies.gh_token;
  const store = loadStore();
  const s = token && store.sessions[token];
  if (!s || !s.active) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  const account = store.accounts[s.username];
  if (!account) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }

  if (!currentPassword) {
    sendJson(res, 200, { ok: false, error: "Current password is required" });
    return;
  }
  if (account.password !== currentPassword) {
    sendJson(res, 200, { ok: false, error: "Current password is incorrect" });
    return;
  }
  if (newPassword !== confirmPassword) {
    sendJson(res, 200, { ok: false, error: "Password confirmation does not match" });
    return;
  }
  if (!validatePassword(newPassword)) {
    sendJson(res, 200, { ok: false, error: "Password requirements are not satisfied" });
    return;
  }

  account.password = newPassword;
  saveStore(store);
  sendJson(res, 200, { ok: true, message: "Password updated" });
}

// --- API handlers ---
function handleRegister(req, res, body) {
  const params = parseUrlEncoded(body);
  const username = params.username || "";
  const email = params.email || "";
  const password = params.password || "";
  const confirm = params.confirm || "";
  const agree = params.terms === "on" || params.terms === "true";
  const store = loadStore();
  const errors = {};

  if (!validateUsername(username)) errors.username = "Username format is invalid";
  else if (store.accounts[username]) errors.username = "Username already exists";

  if (!validateEmail(email)) errors.email = "Email format is invalid";
  else if (Object.values(store.accounts).some((a) => a.email === email.trim()))
    errors.email = "Email already exists";

  if (!validatePassword(password) || password !== confirm)
    errors.password = "Password requirements are not satisfied";

  if (!agree) errors.terms = "Agree to terms is required";

  if (Object.keys(errors).length) {
    sendHtml(res, 200, renderRegisterPage(errors, username, email));
    return;
  }

  store.accounts[username] = {
    username,
    email: email.trim(),
    password,
    emailVerified: true,
    available: true,
  };
  saveStore(store);
  res.writeHead(302, { Location: "/signin" });
  res.end();
}

function handleSignIn(req, res, body) {
  const params = parseUrlEncoded(body);
  const login = (params.login || "").trim();
  const password = params.password || "";
  const store = loadStore();
  const account = Object.values(store.accounts).find(
    (a) => a.email === login || a.username === login
  );
  if (!account || account.password !== password || account.available === false) {
    sendHtml(res, 200, renderSigninPage("Invalid credentials", login));
    return;
  }
  const token = crypto.randomBytes(24).toString("hex");
  store.sessions[token] = {
    username: account.username,
    accountId: account.username,
    active: true,
  };
  saveStore(store);
  res.writeHead(302, {
    Location: "/workspace",
    "Set-Cookie": "gh_token=" + token + "; Path=/; HttpOnly",
  });
  res.end();
}

function handleSession(req, res) {
  const cookies = parseCookies(req);
  const token = cookies.gh_token;
  const store = loadStore();
  const s = token && store.sessions[token];
  if (!s) { sendJson(res, 401, { ok: false }); return; }
  sendJson(res, 200, { ok: true, username: s.username });
}

// --- Organizations (REQ-2-1-1) ---
function currentUsername(req) {
  const cookies = parseCookies(req);
  const token = cookies.gh_token;
  const store = loadStore();
  const s = token && store.sessions[token];
  return s && s.active ? s.username : null;
}

function repoVisibleTo(repo, username) {
  if (!repo) return false;
  if (repo.visibility === "public") return true;
  if (!username) return false;
  if (repo.owner === username) return true;
  return false;
}

function handleOrgs(req, res) {
  const store = loadStore();
  const username = currentUsername(req);
  const orgs = Object.values(store.orgs || {})
    .filter((o) => {
      if (!username) return false;
      if (o.owner === username) return true;
      if (Array.isArray(o.owners) && o.owners.includes(username)) return true;
      if (Array.isArray(o.members) && o.members.includes(username)) return true;
      return false;
    })
    .map((o) => ({ name: o.name }));
  sendJson(res, 200, { ok: true, orgs });
}

// --- Create organization (REQ-2-1-2) ---
function validateOrgName(name) {
  if (typeof name !== "string") return false;
  if (name.length < 1 || name.length > 39) return false;
  return /^[a-z0-9]+(-[a-z0-9]+)*$/.test(name);
}

function handleCreateOrg(req, res, body) {
  let params;
  try { params = JSON.parse(body || "{}"); } catch { params = {}; }
  const name = params.name || "";
  const displayName = params.displayName || "";
  const username = currentUsername(req);
  if (!username) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  const store = loadStore();
  const errors = [];
  if (store.orgs && store.orgs[name]) {
    errors.push("Organization name already exists");
  } else {
    if (!validateOrgName(name)) {
      errors.push("Organization name format is invalid");
    }
    const trimmedDisplay = displayName.trim();
    if (trimmedDisplay.length < 1) {
      errors.push("Display name is required");
    } else if (trimmedDisplay.length > 100) {
      errors.push("Display name is too long");
    }
  }
  if (errors.length) {
    sendJson(res, 200, { ok: false, errors });
    return;
  }
  store.orgs[name] = {
    name,
    displayName: displayName.trim(),
    owner: username,
    repos: [],
  };
  saveStore(store);
  sendJson(res, 200, { ok: true, name });
}

function handleOrgDetails(req, res, orgName) {
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  sendJson(res, 200, { ok: true, org: { name: org.name, displayName: org.displayName || org.name, owner: org.owner || "" } });
}

function handleOrgRepos(req, res, orgName) {
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  const username = currentUsername(req);
  const repos = (org.repos || [])
    .map((name) => store.repos && store.repos[name])
    .filter((r) => r && repoVisibleTo(r, username))
    .map((r) => ({
      name: r.name,
      description: r.description || "",
      visibility: r.visibility,
      updatedAt: r.updatedAt || "",
    }));
  sendJson(res, 200, { ok: true, repos });
}

// --- Organization members (REQ-2-2-3) ---
function handleOrgMembers(req, res, orgName) {
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  const members = [];
  const seen = {};
  function add(username, role) {
    if (!username || seen[username]) return;
    seen[username] = true;
    members.push({ username, role });
  }
  if (org.owner) add(org.owner, "Owner");
  (org.owners || []).forEach((u) => add(u, "Owner"));
  (org.members || []).forEach((u) => add(u, "Member"));
  sendJson(res, 200, { ok: true, members });
}

function handleOrgAddMember(req, res, orgName, body) {
  let params;
  try { params = JSON.parse(body || "{}"); } catch { params = {}; }
  const username = (params.username || "").trim();
  const actor = currentUsername(req);
  if (!actor) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  if (!isOrgOwner(org, actor)) {
    sendJson(res, 403, { ok: false, error: "Only the organization owner can add members" });
    return;
  }
  if (!store.accounts[username]) {
    sendJson(res, 200, { ok: false, error: "Account not found" });
    return;
  }
  const orgMembers = org.members || [];
  const orgOwners = org.owners || [];
  if (org.owner === username || orgOwners.includes(username) || orgMembers.includes(username)) {
    sendJson(res, 200, { ok: false, error: "Account is already a member" });
    return;
  }
  org.members = orgMembers;
  org.members.push(username);
  saveStore(store);
  sendJson(res, 200, { ok: true, username });
}

// --- Remove a member from an organization (REQ-2-2-4) ---
function handleOrgRemoveMember(req, res, orgName, memberName) {
  const actor = currentUsername(req);
  if (!actor) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  if (!isOrgOwner(org, actor)) {
    sendJson(res, 403, { ok: false, error: "Only the organization owner can remove members" });
    return;
  }
  if (org.owner === memberName) {
    sendJson(res, 200, { ok: false, error: "Cannot remove the organization owner" });
    return;
  }
  const orgMembers = org.members || [];
  const orgOwners = org.owners || [];
  const inMembers = orgMembers.includes(memberName);
  const inOwners = orgOwners.includes(memberName);
  if (!inMembers && !inOwners) {
    sendJson(res, 200, { ok: false, error: "Account is not a member" });
    return;
  }
  org.members = orgMembers.filter((m) => m !== memberName);
  org.owners = orgOwners.filter((m) => m !== memberName);
  saveStore(store);
  sendJson(res, 200, { ok: true, username: memberName });
}

// --- Teams (REQ-2-2-1, REQ-2-2-2) ---
function validateTeamName(name) {
  if (typeof name !== "string") return false;
  if (name.length < 1 || name.length > 50) return false;
  return /^[a-z0-9]+(-[a-z0-9]+)*$/.test(name);
}

function isOrgOwner(org, username) {
  if (!org || !username) return false;
  if (org.owner === username) return true;
  if (Array.isArray(org.owners) && org.owners.includes(username)) return true;
  return false;
}

// A team is a descendant of `teamName` if it is `teamName` itself or its
// parent chain reaches `teamName`.
function isDescendant(org, teamName, candidate) {
  let current = candidate;
  const seen = {};
  while (current) {
    if (current === teamName) return true;
    if (seen[current]) return false; // cycle guard
    seen[current] = true;
    const t = org.teams && org.teams[current];
    current = t && t.parent ? t.parent : null;
  }
  return false;
}

function handleOrgTeams(req, res, orgName) {
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  const teams = Object.values(org.teams || {}).map((t) => ({ name: t.name }));
  sendJson(res, 200, { ok: true, teams });
}

function handleCreateTeam(req, res, orgName, body) {
  let params;
  try { params = JSON.parse(body || "{}"); } catch { params = {}; }
  const name = params.name || "";
  const username = currentUsername(req);
  if (!username) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  if (!isOrgOwner(org, username)) {
    sendJson(res, 403, { ok: false, error: "Only the organization owner can create teams" });
    return;
  }
  org.teams = org.teams || {};
  if (org.teams[name]) {
    sendJson(res, 200, { ok: false, error: "Team name format is invalid" });
    return;
  }
  if (!validateTeamName(name)) {
    sendJson(res, 200, { ok: false, error: "Team name format is invalid" });
    return;
  }
  org.teams[name] = { name, org: orgName };
  saveStore(store);
  sendJson(res, 200, { ok: true, name });
}

function handleTeamDetails(req, res, orgName, teamName) {
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  const team = org.teams && org.teams[teamName];
  if (!team) { sendJson(res, 404, { ok: false, error: "Team not found" }); return; }
  const members = (team.members || []).map((m) => ({ username: m }));
  // Available parent options: every team in the org except this team itself.
  const parentOptions = Object.keys(org.teams || {})
    .filter((name) => name !== teamName)
    .map((name) => ({ name }));
  sendJson(res, 200, {
    ok: true,
    team: {
      name: team.name,
      org: orgName,
      parent: team.parent || null,
      members,
      parentOptions,
    },
  });
}

function handleTeamAddMember(req, res, orgName, teamName, body) {
  let params;
  try { params = JSON.parse(body || "{}"); } catch { params = {}; }
  const username = params.username || "";
  const actor = currentUsername(req);
  if (!actor) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  if (!isOrgOwner(org, actor)) {
    sendJson(res, 403, { ok: false, error: "Only the organization owner can manage team members" });
    return;
  }
  const team = org.teams && org.teams[teamName];
  if (!team) { sendJson(res, 404, { ok: false, error: "Team not found" }); return; }
  // The added user must be a member of the organization.
  const orgMembers = org.members || [];
  if (!orgMembers.includes(username)) {
    sendJson(res, 200, { ok: false, error: "User is not an organization member" });
    return;
  }
  if (!store.accounts[username]) {
    sendJson(res, 200, { ok: false, error: "User is not an organization member" });
    return;
  }
  team.members = team.members || [];
  if (team.members.includes(username)) {
    sendJson(res, 200, { ok: false, error: "User is already a team member" });
    return;
  }
  team.members.push(username);
  saveStore(store);
  sendJson(res, 200, { ok: true, username });
}

function handleTeamRemoveMember(req, res, orgName, teamName, memberName) {
  const actor = currentUsername(req);
  if (!actor) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  if (!isOrgOwner(org, actor)) {
    sendJson(res, 403, { ok: false, error: "Only the organization owner can manage team members" });
    return;
  }
  const team = org.teams && org.teams[teamName];
  if (!team) { sendJson(res, 404, { ok: false, error: "Team not found" }); return; }
  team.members = (team.members || []).filter((m) => m !== memberName);
  saveStore(store);
  sendJson(res, 200, { ok: true, username: memberName });
}

function handleTeamSetParent(req, res, orgName, teamName, body) {
  let params;
  try { params = JSON.parse(body || "{}"); } catch { params = {}; }
  const parent = params.parent || null;
  const actor = currentUsername(req);
  if (!actor) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  if (!org) { sendJson(res, 404, { ok: false, error: "Organization not found" }); return; }
  if (!isOrgOwner(org, actor)) {
    sendJson(res, 403, { ok: false, error: "Only the organization owner can manage team settings" });
    return;
  }
  const team = org.teams && org.teams[teamName];
  if (!team) { sendJson(res, 404, { ok: false, error: "Team not found" }); return; }
  if (parent) {
    const parentTeam = org.teams && org.teams[parent];
    if (!parentTeam) {
      sendJson(res, 200, { ok: false, error: "Parent team not found" });
      return;
    }
    // Reject a change that would make the team its own ancestor.
    if (isDescendant(org, teamName, parent)) {
      sendJson(res, 200, { ok: false, error: "Cyclic team hierarchy is not allowed" });
      return;
    }
  }
  team.parent = parent || null;
  saveStore(store);
  sendJson(res, 200, { ok: true, parent: team.parent });
}

// Serve the team page with the current parent value and parent options
// embedded so the Settings combobox is populated synchronously on load.
function serveTeamPage(req, res, orgName, teamName) {
  const store = loadStore();
  const org = store.orgs && store.orgs[orgName];
  const team = org && org.teams && org.teams[teamName];
  const parentOptions = org
    ? Object.keys(org.teams || {}).filter((n) => n !== teamName).map((n) => ({ name: n }))
    : [];
  const data = {
    team: {
      name: teamName,
      org: orgName,
      parent: team ? team.parent || null : null,
      members: team ? (team.members || []).map((m) => ({ username: m })) : [],
      parentOptions,
    },
  };
  const file = path.join(DIST_DIR, "team.html");
  fs.readFile(file, (err, buf) => {
    if (err) { send(res, 404, "not found\n"); return; }
    let html = buf.toString("utf8");
    html = html.replace("__TEAM_DATA_JSON__", JSON.stringify(data).replace(/</g, "\\u003c"));
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Content-Length": Buffer.byteLength(html) });
    res.end(html);
  });
}

// --- Repository access management (REQ-2-3) ---
function isRepoAdmin(repo, username) {
  if (!repo || !username) return false;
  if (repo.owner === username) return true;
  if (Array.isArray(repo.admins) && repo.admins.includes(username)) return true;
  const org = repo.org && loadStore().orgs && loadStore().orgs[repo.org];
  if (org && isOrgOwner(org, username)) return true;
  return false;
}

function handleRepoAccess(req, res, repoName) {
  const store = loadStore();
  const repo = store.repos && store.repos[repoName];
  if (!repo) { sendJson(res, 404, { ok: false, error: "Repository not found" }); return; }
  const username = currentUsername(req);
  if (!username) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  if (!isRepoAdmin(repo, username)) {
    sendJson(res, 403, { ok: false, error: "Only repository admins can manage access" });
    return;
  }
  const access = Object.keys(repo.access || {}).map((name) => ({
    name,
    role: repo.access[name],
  }));
  sendJson(res, 200, { ok: true, access });
}

function handleRepoAddAccess(req, res, repoName, body) {
  let params;
  try { params = JSON.parse(body || "{}"); } catch { params = {}; }
  const name = (params.name || "").trim();
  const role = (params.role || "").trim();
  const store = loadStore();
  const repo = store.repos && store.repos[repoName];
  if (!repo) { sendJson(res, 404, { ok: false, error: "Repository not found" }); return; }
  const username = currentUsername(req);
  if (!username) { sendJson(res, 401, { ok: false, error: "Not signed in" }); return; }
  if (!isRepoAdmin(repo, username)) {
    sendJson(res, 403, { ok: false, error: "Only repository admins can manage access" });
    return;
  }
  if (!name) { sendJson(res, 200, { ok: false, error: "Team name is required" }); return; }
  if (role !== "Read" && role !== "Write" && role !== "Admin") {
    sendJson(res, 200, { ok: false, error: "Role is invalid" });
    return;
  }
  // The team must belong to the repository's organization.
  const org = repo.org && store.orgs && store.orgs[repo.org];
  if (!org || !org.teams || !org.teams[name]) {
    sendJson(res, 200, { ok: false, error: "Team not found" });
    return;
  }
  repo.access = repo.access || {};
  repo.access[name] = role;
  saveStore(store);
  sendJson(res, 200, { ok: true, name, role });
}

function handleRepoTeams(req, res, repoName) {
  const store = loadStore();
  const repo = store.repos && store.repos[repoName];
  if (!repo) { sendJson(res, 404, { ok: false, error: "Repository not found" }); return; }
  const org = repo.org && store.orgs && store.orgs[repo.org];
  const teams = org
    ? Object.keys(org.teams || {}).map((name) => ({ name }))
    : [];
  sendJson(res, 200, { ok: true, teams });
}

function isAuthenticated(req) {
  const cookies = parseCookies(req);
  const token = cookies.gh_token;
  const store = loadStore();
  const s = token && store.sessions[token];
  return !!(s && s.active);
}

function handleSignOut(req, res) {
  const cookies = parseCookies(req);
  const token = cookies.gh_token;
  const store = loadStore();
  if (token) delete store.sessions[token];
  saveStore(store);
  res.writeHead(200, {
    "Content-Type": "application/json; charset=utf-8",
    "Set-Cookie": "gh_token=; Path=/; HttpOnly; Max-Age=0",
  });
  res.end(JSON.stringify({ ok: true }));
}

const server = http.createServer((req, res) => {
  try {
    handle(req, res);
  } catch (err) {
    try { send(res, 400, "bad request\n"); } catch { /* socket already gone */ }
  }
});

function handle(req, res) {
  const pathname = pathname0(req);

  if (pathname === "/api/store" && (req.method === "GET" || req.method === "PUT")) {
    const file = path.join(__dirname, "store.json");
    if (req.method === "GET") {
      fs.readFile(file, (err, data) => {
        if (err) { send(res, 404, "{}\n"); return; }
        res.writeHead(200, { "content-type": "application/json" });
        res.end(data);
      });
    } else {
      let body = "";
      req.on("data", (chunk) => { body += chunk; });
      req.on("end", () => {
        const tmp = file + ".tmp";
        fs.writeFile(tmp, body, (err) => {
          if (err) { send(res, 500, "write failed\n"); return; }
          fs.rename(tmp, file, (err2) => send(res, err2 ? 500 : 204, err2 ? "write failed\n" : ""));
        });
      });
    }
    return;
  }

  if (pathname === "/api/session" && req.method === "GET") {
    handleSession(req, res);
    return;
  }
  if (pathname === "/api/signout" && req.method === "POST") {
    readBody(req, () => handleSignOut(req, res));
    return;
  }
  if (pathname === "/api/password" && req.method === "POST") {
    readBody(req, (body) => handlePasswordChange(req, res, body));
    return;
  }
  if (pathname === "/api/orgs" && req.method === "GET") {
    handleOrgs(req, res);
    return;
  }
  if (pathname === "/api/orgs" && req.method === "POST") {
    readBody(req, (body) => handleCreateOrg(req, res, body));
    return;
  }
  if (pathname.startsWith("/api/org/") && pathname.endsWith("/repos") && req.method === "GET") {
    const orgName = decodeURIComponent(pathname.slice("/api/org/".length, -"/repos".length));
    handleOrgRepos(req, res, orgName);
    return;
  }
  if (pathname.startsWith("/api/org/") && pathname.endsWith("/members") && !pathname.includes("/teams/") && req.method === "GET") {
    const orgName = decodeURIComponent(pathname.slice("/api/org/".length, -"/members".length));
    handleOrgMembers(req, res, orgName);
    return;
  }
  if (pathname.startsWith("/api/org/") && pathname.endsWith("/members") && !pathname.includes("/teams/") && req.method === "POST") {
    const orgName = decodeURIComponent(pathname.slice("/api/org/".length, -"/members".length));
    readBody(req, (body) => handleOrgAddMember(req, res, orgName, body));
    return;
  }
  if (pathname.startsWith("/api/org/") && pathname.endsWith("/teams") && req.method === "GET") {
    const orgName = decodeURIComponent(pathname.slice("/api/org/".length, -"/teams".length));
    handleOrgTeams(req, res, orgName);
    return;
  }
  if (pathname.startsWith("/api/org/") && pathname.endsWith("/teams") && req.method === "POST") {
    const orgName = decodeURIComponent(pathname.slice("/api/org/".length, -"/teams".length));
    readBody(req, (body) => handleCreateTeam(req, res, orgName, body));
    return;
  }
  // POST /api/org/<org>/teams/<team>/members
  if (pathname.startsWith("/api/org/") && pathname.endsWith("/members") && req.method === "POST") {
    const rest = pathname.slice("/api/org/".length, -"/members".length);
    const slashIdx = rest.indexOf("/teams/");
    const orgName = decodeURIComponent(rest.slice(0, slashIdx));
    const teamName = decodeURIComponent(rest.slice(slashIdx + "/teams/".length));
    readBody(req, (body) => handleTeamAddMember(req, res, orgName, teamName, body));
    return;
  }
  // DELETE /api/org/<org>/members/<username>
  if (pathname.startsWith("/api/org/") && pathname.includes("/members/") && !pathname.includes("/teams/") && req.method === "DELETE") {
    const rest = pathname.slice("/api/org/".length);
    const membersIdx = rest.indexOf("/members/");
    const orgName = decodeURIComponent(rest.slice(0, membersIdx));
    const memberName = decodeURIComponent(rest.slice(membersIdx + "/members/".length));
    handleOrgRemoveMember(req, res, orgName, memberName);
    return;
  }
  // DELETE /api/org/<org>/teams/<team>/members/<username>
  if (pathname.startsWith("/api/org/") && pathname.includes("/members/") && req.method === "DELETE") {
    const rest = pathname.slice("/api/org/".length);
    const membersIdx = rest.indexOf("/members/");
    const orgTeam = rest.slice(0, membersIdx);
    const memberName = decodeURIComponent(rest.slice(membersIdx + "/members/".length));
    const slashIdx = orgTeam.indexOf("/teams/");
    const orgName = decodeURIComponent(orgTeam.slice(0, slashIdx));
    const teamName = decodeURIComponent(orgTeam.slice(slashIdx + "/teams/".length));
    handleTeamRemoveMember(req, res, orgName, teamName, memberName);
    return;
  }
  // POST /api/org/<org>/teams/<team>/parent
  if (pathname.startsWith("/api/org/") && pathname.endsWith("/parent") && req.method === "POST") {
    const rest = pathname.slice("/api/org/".length, -"/parent".length);
    const slashIdx = rest.indexOf("/teams/");
    const orgName = decodeURIComponent(rest.slice(0, slashIdx));
    const teamName = decodeURIComponent(rest.slice(slashIdx + "/teams/".length));
    readBody(req, (body) => handleTeamSetParent(req, res, orgName, teamName, body));
    return;
  }
  if (pathname.startsWith("/api/org/") && pathname.includes("/teams/") && req.method === "GET") {
    const rest = pathname.slice("/api/org/".length);
    const slashIdx = rest.indexOf("/teams/");
    const orgName = decodeURIComponent(rest.slice(0, slashIdx));
    const teamName = decodeURIComponent(rest.slice(slashIdx + "/teams/".length));
    handleTeamDetails(req, res, orgName, teamName);
    return;
  }
  if (pathname.startsWith("/api/org/") && req.method === "GET") {
    const orgName = decodeURIComponent(pathname.slice("/api/org/".length));
    handleOrgDetails(req, res, orgName);
    return;
  }
  // GET /api/repo/<name>/access
  if (pathname.startsWith("/api/repo/") && pathname.endsWith("/access") && req.method === "GET") {
    const repoName = decodeURIComponent(pathname.slice("/api/repo/".length, -"/access".length));
    handleRepoAccess(req, res, repoName);
    return;
  }
  // POST /api/repo/<name>/access
  if (pathname.startsWith("/api/repo/") && pathname.endsWith("/access") && req.method === "POST") {
    const repoName = decodeURIComponent(pathname.slice("/api/repo/".length, -"/access".length));
    readBody(req, (body) => handleRepoAddAccess(req, res, repoName, body));
    return;
  }
  // GET /api/repo/<name>/teams
  if (pathname.startsWith("/api/repo/") && pathname.endsWith("/teams") && req.method === "GET") {
    const repoName = decodeURIComponent(pathname.slice("/api/repo/".length, -"/teams".length));
    handleRepoTeams(req, res, repoName);
    return;
  }
  if (pathname === "/signin" && req.method === "POST") {
    readBody(req, (body) => handleSignIn(req, res, body));
    return;
  }
  if (pathname === "/register" && req.method === "POST") {
    readBody(req, (body) => handleRegister(req, res, body));
    return;
  }
  if (pathname === "/recover" && req.method === "POST") {
    readBody(req, (body) => handleRecoverPost(req, res, body));
    return;
  }
  if (pathname === "/recover/reset" && req.method === "POST") {
    readBody(req, (body) => handleRecoverReset(req, res, body));
    return;
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    send(res, 405, "method not allowed\n");
    return;
  }
  let decoded;
  try {
    decoded = decodeURIComponent(new URL(req.url, "http://localhost").pathname);
  } catch {
    send(res, 400, "bad request\n");
    return;
  }
  if (decoded.includes("\0")) { send(res, 400, "bad request\n"); return; }
  if (decoded === "/workspace" || decoded.startsWith("/repo/") || decoded === "/settings" || decoded === "/password" || decoded === "/organizations" || decoded === "/organizations/new" || decoded.startsWith("/org/")) {
    if (!isAuthenticated(req)) {
      res.writeHead(302, { Location: "/signin" });
      res.end();
      return;
    }
  }
  if (decoded === "/organizations/new") {
    serveNext(req, res, ["new-org.html"], 0);
    return;
  }
  if (decoded.startsWith("/repo/")) {
    const rest = decoded.slice("/repo/".length);
    const parts = rest.split("/").filter(Boolean);
    // /repo/<name>/settings/access
    if (parts.length >= 3 && parts[1] === "settings" && parts[2] === "access") {
      serveNext(req, res, ["repo-access.html"], 0);
      return;
    }
    // /repo/<name>/settings
    if (parts.length >= 2 && parts[1] === "settings") {
      serveNext(req, res, ["repo-settings.html"], 0);
      return;
    }
    const repoName = parts.length >= 2 ? decodeURIComponent(parts[1]) : decodeURIComponent(parts[0] || "");
    const store = loadStore();
    const repo = store.repos && store.repos[repoName];
    const username = currentUsername(req);
    if (repo && !repoVisibleTo(repo, username)) {
      sendHtml(res, 200, renderAccessDeniedPage());
      return;
    }
    serveNext(req, res, ["repo.html"], 0);
    return;
  }
  if (decoded.startsWith("/org/")) {
    const rest = decoded.slice("/org/".length);
    const parts = rest.split("/").filter(Boolean);
    // /org/<name>/teams/new
    if (parts.length >= 3 && parts[1] === "teams" && parts[2] === "new") {
      serveNext(req, res, ["new-team.html"], 0);
      return;
    }
    // /org/<name>/teams/<teamname>
    if (parts.length >= 3 && parts[1] === "teams") {
      const teamName = decodeURIComponent(parts[2]);
      serveTeamPage(req, res, decodeURIComponent(parts[0]), teamName);
      return;
    }
    // /org/<name>/teams
    if (parts.length === 2 && parts[1] === "teams") {
      serveNext(req, res, ["teams.html"], 0);
      return;
    }
    // /org/<name>/people
    if (parts.length === 2 && parts[1] === "people") {
      serveNext(req, res, ["people.html"], 0);
      return;
    }
    serveNext(req, res, ["org.html"], 0);
    return;
  }
  const rel = decoded === "/" ? "index.html" : decoded.replace(/^\/+/, "");
  serveNext(req, res, path.extname(rel) ? [rel] : [rel + ".html", rel], 0);
}

function pathname0(req) {
  try { return decodeURIComponent(new URL(req.url, "http://localhost").pathname); }
  catch { return ""; }
}

server.keepAliveTimeout = 600000;
server.headersTimeout = 610000;

server.listen(PORT, () => {
  console.log(`backend listening on port ${PORT}, serving ${DIST_DIR}`);
});
