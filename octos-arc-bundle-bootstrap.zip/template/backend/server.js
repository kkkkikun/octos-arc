"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");

const DIST_DIR = path.resolve(__dirname, "..", "frontend", "dist");
const STORE_FILE = path.resolve(__dirname, "store.json");
const PORT = Number(process.env.PORT || 43100);

const MIME_TYPES = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
};

function send(res, status, body, type) {
  res.writeHead(status, {
    "Content-Type": type || "text/plain; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}

function sendJson(res, status, obj) {
  send(res, status, JSON.stringify(obj), "application/json; charset=utf-8");
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (c) => {
      data += c;
      if (data.length > 1e7) req.destroy();
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

function loadStore() {
  if (fs.existsSync(STORE_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(STORE_FILE, "utf8"));
    } catch (e) {
      // fall through to seed
    }
  }
  const seed = {
    workbooks: [
      {
      id: "q3-sales",
      name: "Q3 Sales",
      lastUpdated: "2024-09-30T15:00:00.000Z",
      // The evaluation seed names Sheet1 (Item/Qty, Pen/4) and Sheet2 so that
      // the worksheet flows (add / rename) have a stable pair of tabs to work
      // with; "Add worksheet" still creates a fresh next-available name.
      worksheets: [
        {
          name: "Sheet1",
          active: true,
          rows: 10,
          cols: 10,
          cells: {
            // The sort/filter/validation/pivot seed: A1:C6 with headers
            // Region/Sales/Status and rows East/1200/Open, North/800/Closed,
            // South/700/Open.
            A1: "Region",
            B1: "Sales",
            C1: "Status",
            A2: "East",
            B2: "1200",
            C2: "Open",
            A3: "North",
            B3: "800",
            C3: "Closed",
            A4: "South",
            B4: "700",
            C4: "Open",
          },
          selection: { start: "A1", end: "A1" },
        },
        {
          name: "Sheet2",
          active: false,
          rows: 10,
          cols: 10,
          cells: {},
          selection: { start: "A1", end: "A1" },
        },
      ],
    },
    {
      id: "inventory",
      name: "Inventory",
      lastUpdated: "2024-09-30T15:00:00.000Z",
      // REQ-3 world: range A1:B2 containing Item/Qty and Pen/4, with a
      // target range D1:E2 for paste flows. The editing module (REQ-3-1-1)
      // opens this workbook to edit cells through the grid or formula bar.
      worksheets: [
        {
          name: "Sheet1",
          active: true,
          rows: 10,
          cols: 10,
          cells: {
            A1: "Item",
            B1: "Qty",
            A2: "Pen",
            B2: "4",
          },
          selection: { start: "A1", end: "A1" },
        },
      ],
    },
    ],
  };
  saveStore(seed);
  return seed;
}

function saveStore(store) {
  fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2));
}

function slugify(name) {
  return String(name)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "workbook";
}

function colName(i) {
  let s = "";
  i = i + 1;
  while (i > 0) {
    const rem = (i - 1) % 26;
    s = String.fromCharCode(65 + rem) + s;
    i = Math.floor((i - 1) / 26);
  }
  return s;
}

function parseCSV(text) {
  const rows = [];
  let row = [];
  let field = "";
  let inQuotes = false;
  let i = 0;
  const n = text.length;
  while (i < n) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (i + 1 < n && text[i + 1] === '"') {
          field += '"';
          i += 2;
        } else {
          inQuotes = false;
          i += 1;
        }
      } else {
        field += ch;
        i += 1;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
        i += 1;
      } else if (ch === ",") {
        row.push(field);
        field = "";
        i += 1;
      } else if (ch === "\n") {
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
        i += 1;
      } else if (ch === "\r") {
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
        i += i + 1 < n && text[i + 1] === "\n" ? 2 : 1;
      } else {
        field += ch;
        i += 1;
      }
    }
  }
  if (inQuotes) {
    throw new Error("Invalid CSV file format. Import failed.");
  }
  if (field !== "" || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows;
}

function serveNext(req, res, rels, i) {
  if (i >= rels.length) {
    send(res, 404, "not found\n");
    return;
  }
  const file = path.normalize(path.join(DIST_DIR, rels[i]));
  if (file !== DIST_DIR && !file.startsWith(DIST_DIR + path.sep)) {
    send(res, 404, "not found\n");
    return;
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      serveNext(req, res, rels, i + 1);
      return;
    }
    const type = MIME_TYPES[path.extname(file).toLowerCase()] || "application/octet-stream";
    res.writeHead(200, { "Content-Type": type, "Content-Length": data.length });
    res.end(req.method === "HEAD" ? undefined : data);
  });
}

const server = http.createServer(async (req, res) => {
  let url;
  try {
    url = new URL(req.url, "http://localhost");
  } catch {
    send(res, 400, "bad request\n");
    return;
  }
  const pathname = decodeURIComponent(url.pathname);
  const method = req.method;

  // ---- API routes ----
  if (pathname === "/api/workbooks" && method === "GET") {
    const store = loadStore();
    const list = store.workbooks.map((w) => ({
      id: w.id,
      name: w.name,
      lastUpdated: w.lastUpdated,
    }));
    sendJson(res, 200, { workbooks: list });
    return;
  }

  if (pathname === "/api/workbooks" && method === "POST") {
    const body = await readBody(req).catch(() => "");
    let data = {};
    try {
      data = JSON.parse(body || "{}");
    } catch (e) {
      data = {};
    }
    const name = String(data.name || "Untitled workbook").trim() || "Untitled workbook";
    const store = loadStore();
    const id = slugify(name) + "-" + Date.now().toString(36);
    const wb = {
      id,
      name,
      lastUpdated: new Date().toISOString(),
      worksheets: [
        { name: "Sheet1", active: true, rows: 100, cols: 26, cells: {}, selection: { start: "A1", end: "A1" } },
      ],
    };
    store.workbooks.push(wb);
    saveStore(store);
    sendJson(res, 201, wb);
    return;
  }

  if (pathname === "/api/import-csv" && method === "POST") {
    const body = await readBody(req).catch(() => "");
    let data = {};
    try {
      data = JSON.parse(body || "{}");
    } catch (e) {
      data = {};
    }
    const filename = String(data.filename || "");
    const content = String(data.content || "");
    let rows;
    try {
      rows = parseCSV(content);
    } catch (e) {
      sendJson(res, 400, { error: e.message || "Invalid CSV file format. Import failed." });
      return;
    }
    const baseName = filename.replace(/\.csv$/i, "") || "Imported workbook";
    const store = loadStore();
    const id = slugify(baseName) + "-" + Date.now().toString(36);
    const cells = {};
    const numRows = rows.length;
    const numCols = rows.reduce((m, r) => Math.max(m, r.length), 0);
    for (let r = 0; r < numRows; r++) {
      for (let c = 0; c < numCols; c++) {
        const coord = colName(c) + (r + 1);
        cells[coord] = rows[r][c] !== undefined ? rows[r][c] : "";
      }
    }
    const wb = {
      id,
      name: baseName,
      lastUpdated: new Date().toISOString(),
      worksheets: [
        { name: "Sheet1", active: true, rows: numRows, cols: numCols, cells, selection: { start: "A1", end: "A1" } },
      ],
    };
    store.workbooks.push(wb);
    saveStore(store);
    sendJson(res, 201, wb);
    return;
  }

  const wbMatch = pathname.match(/^\/api\/workbooks\/([^/]+)$/);
  if (wbMatch && method === "GET") {
    const store = loadStore();
    const wb = store.workbooks.find((w) => w.id === wbMatch[1]);
    if (!wb) {
      sendJson(res, 404, { error: "not found" });
      return;
    }
    sendJson(res, 200, wb);
    return;
  }

  if (wbMatch && method === "PUT") {
    const body = await readBody(req).catch(() => "");
    let data = {};
    try {
      data = JSON.parse(body || "{}");
    } catch (e) {
      data = {};
    }
    const store = loadStore();
    const idx = store.workbooks.findIndex((w) => w.id === wbMatch[1]);
    if (idx < 0) {
      sendJson(res, 404, { error: "not found" });
      return;
    }
    const wb = store.workbooks[idx];
    if (typeof data.name === "string") {
      const trimmed = data.name.trim();
      if (!trimmed) {
        sendJson(res, 400, { error: "Workbook name cannot be empty" });
        return;
      }
      wb.name = trimmed;
    }
    if (Array.isArray(data.worksheets)) {
      const seen = {};
      for (let i = 0; i < data.worksheets.length; i++) {
        const ws = data.worksheets[i];
        const wsName = String(ws.name || "").trim();
        if (!wsName) {
          sendJson(res, 400, { error: "Worksheet name cannot be empty" });
          return;
        }
        if (seen[wsName]) {
          sendJson(res, 400, { error: "Worksheet name already exists" });
          return;
        }
        seen[wsName] = true;
        ws.name = wsName;
      }
      wb.worksheets = data.worksheets;
    }
    wb.lastUpdated = new Date().toISOString();
    saveStore(store);
    sendJson(res, 200, wb);
    return;
  }

  if (method !== "GET" && method !== "HEAD") {
    send(res, 405, "method not allowed\n");
    return;
  }

  // ---- Static frontend ----
  const rel = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  serveNext(req, res, path.extname(rel) ? [rel] : [rel + ".html", rel], 0);
});

server.listen(PORT, () => {
  console.log(`backend listening on port ${PORT}, serving ${DIST_DIR}`);
});

