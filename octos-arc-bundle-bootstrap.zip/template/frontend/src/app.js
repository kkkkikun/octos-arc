(function () {
  "use strict";

  var isEditor = document.getElementById("grid") != null;

  if (isEditor) {
    initEditor();
  } else {
    initHome();
  }

  function initHome() {
    var list = document.getElementById("workbook-list");
    var newBtn = document.getElementById("new-workbook-btn");
    var dialog = document.getElementById("new-workbook-dialog");
    var createBtn = document.getElementById("create-btn");
    var cancelBtn = document.getElementById("cancel-btn");
    var newWorkbookError = document.getElementById("new-workbook-error");
    var importBtn = document.getElementById("import-csv-btn");
    var importDialog = document.getElementById("import-csv-dialog");
    var csvFileInput = document.getElementById("csv-file-input");
    var confirmImportBtn = document.getElementById("confirm-import-btn");
    var importCancelBtn = document.getElementById("import-cancel-btn");
    var importError = document.getElementById("import-error");

    function loadList() {
      fetch("/api/workbooks")
        .then(function (r) {
          return r.json();
        })
        .then(function (data) {
          list.innerHTML = "";
          (data.workbooks || []).forEach(function (wb) {
            var li = document.createElement("li");
            var a = document.createElement("a");
            a.href = "editor.html?workbook=" + encodeURIComponent(wb.id);
            a.textContent = wb.name;
            var span = document.createElement("span");
            span.className = "last-updated";
            span.textContent = "Last updated: " + formatDate(wb.lastUpdated);
            li.appendChild(a);
            li.appendChild(span);
            list.appendChild(li);
          });
        })
        .catch(function () {
          list.innerHTML = "<li>Could not load workbooks.</li>";
        });
    }

    newBtn.addEventListener("click", function () {
      newWorkbookError.textContent = "";
      dialog.classList.remove("hidden");
    });

    cancelBtn.addEventListener("click", function () {
      dialog.classList.add("hidden");
      newWorkbookError.textContent = "";
    });

    createBtn.addEventListener("click", function () {
      newWorkbookError.textContent = "";
      fetch("/api/workbooks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "Untitled workbook" }),
      })
        .then(function (r) {
          return r.json().then(function (data) {
            return { ok: r.ok, data: data };
          });
        })
        .then(function (res) {
          if (!res.ok) {
            newWorkbookError.textContent = res.data.error || "Could not create the workbook.";
            return;
          }
          window.location.href = "editor.html?workbook=" + encodeURIComponent(res.data.id);
        })
        .catch(function () {
          newWorkbookError.textContent = "Could not create the workbook.";
        });
    });

    importBtn.addEventListener("click", function () {
      csvFileInput.value = "";
      importError.textContent = "";
      importDialog.classList.remove("hidden");
    });

    importCancelBtn.addEventListener("click", function () {
      importDialog.classList.add("hidden");
      importError.textContent = "";
    });

    confirmImportBtn.addEventListener("click", function () {
      var file = csvFileInput.files && csvFileInput.files[0];
      if (!file) {
        importError.textContent = "Please choose a CSV file.";
        return;
      }
      var reader = new FileReader();
      reader.onload = function () {
        var content = String(reader.result || "");
        fetch("/api/import-csv", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ filename: file.name, content: content }),
        })
          .then(function (r) {
            return r.json().then(function (data) {
              return { ok: r.ok, data: data };
            });
          })
          .then(function (res) {
            if (!res.ok) {
              importError.textContent = res.data.error || "Import failed.";
              return;
            }
            window.location.href = "editor.html?workbook=" + encodeURIComponent(res.data.id);
          })
          .catch(function () {
            importError.textContent = "Import failed.";
          });
      };
      reader.onerror = function () {
        importError.textContent = "Could not read the file.";
      };
      reader.readAsText(file);
    });

    loadList();
  }

  function initEditor() {
    var params = new URLSearchParams(window.location.search);
    var id = params.get("workbook");
    var nameEl = document.getElementById("workbook-name");
    var updatedEl = document.getElementById("last-updated");
    var tabsEl = document.getElementById("worksheet-tabs");
    var gridEl = document.getElementById("grid");
    var formulaEl = document.getElementById("formula-bar");
    var renameBtn = document.getElementById("rename-workbook-btn");
    var exportBtn = document.getElementById("export-csv-btn");
    var renameDialog = document.getElementById("rename-dialog");
    var renameInput = document.getElementById("workbook-name-input");
    var renameSaveBtn = document.getElementById("rename-save-btn");
    var renameCancelBtn = document.getElementById("rename-cancel-btn");
    var renameError = document.getElementById("rename-error");
    var worksheetMenu = document.getElementById("worksheet-menu");
    var renameWsMenuItem = document.getElementById("rename-worksheet-menu-item");
    var deleteWsMenuItem = document.getElementById("delete-worksheet-menu-item");
    var deleteWsDialog = document.getElementById("delete-worksheet-dialog");
    var deleteWsDescription = document.getElementById("delete-worksheet-description");
    var deleteWsError = document.getElementById("delete-worksheet-error");
    var deleteWsConfirmBtn = document.getElementById("delete-worksheet-confirm-btn");
    var deleteWsCancelBtn = document.getElementById("delete-worksheet-cancel-btn");
    var renameWsDialog = document.getElementById("rename-worksheet-dialog");
    var renameWsInput = document.getElementById("worksheet-name-input");
    var renameWsSaveBtn = document.getElementById("rename-worksheet-save-btn");
    var renameWsCancelBtn = document.getElementById("rename-worksheet-cancel-btn");
    var renameWsError = document.getElementById("rename-worksheet-error");
    var addWsBtn = document.getElementById("add-worksheet-btn");
    var addWsError = document.getElementById("add-worksheet-error");
    var dataBtn = document.getElementById("data-btn");
    var dataMenu = document.getElementById("data-menu");
    var createFilterItem = document.getElementById("create-filter-item");
    var clearFilterItem = document.getElementById("clear-filter-item");
    var filterToolbar = document.getElementById("filter-toolbar");
    var filterHeaderButtons = document.getElementById("filter-header-buttons");
    var filterError = document.getElementById("filter-error");
    var filterDialog = document.getElementById("filter-dialog");
    var filterDialogTitle = document.getElementById("filter-dialog-title");
    var filterValues = document.getElementById("filter-values");
    var filterClearSelection = document.getElementById("filter-clear-selection");
    var filterValuesApply = document.getElementById("filter-values-apply");
    var filterConditionApply = document.getElementById("filter-condition-apply");
    var filterCondition = document.getElementById("filter-condition");
    var filterValueInput = document.getElementById("filter-value");
    var filterCancelBtn = document.getElementById("filter-cancel-btn");
    var gridMenu = document.getElementById("grid-menu");
    var copyMenuItem = document.getElementById("copy-menu-item");
    var cutMenuItem = document.getElementById("cut-menu-item");
    var pasteMenuItem = document.getElementById("paste-menu-item");
    var dataValidationItem = document.getElementById("data-validation-item");
    var validationDialog = document.getElementById("data-validation-dialog");
    var validationRuleType = document.getElementById("validation-rule-type");
    var validationAllowedField = document.getElementById("validation-allowed-field");
    var validationAllowedValues = document.getElementById("validation-allowed-values");
    var validationMinField = document.getElementById("validation-min-field");
    var validationMin = document.getElementById("validation-min");
    var validationMaxField = document.getElementById("validation-max-field");
    var validationMax = document.getElementById("validation-max");
    var validationError = document.getElementById("validation-error");
    var validationDeleteBtn = document.getElementById("validation-delete-btn");
    var validationSaveBtn = document.getElementById("validation-save-btn");
    var validationCancelBtn = document.getElementById("validation-cancel-btn");
    var rowMenu = document.getElementById("row-menu");
    var insertRowAboveItem = document.getElementById("insert-row-above-item");
    var insertRowBelowItem = document.getElementById("insert-row-below-item");
    var deleteRowItem = document.getElementById("delete-row-item");
    var rowError = document.getElementById("row-error");
    var columnMenu = document.getElementById("column-menu");
    var insertColumnLeftItem = document.getElementById("insert-column-left-item");
    var insertColumnRightItem = document.getElementById("insert-column-right-item");
    var deleteColumnItem = document.getElementById("delete-column-item");
    var columnError = document.getElementById("column-error");
    var createPivotItem = document.getElementById("create-pivot-item");
    var createPivotDialog = document.getElementById("create-pivot-dialog");
    var pivotSourceRange = document.getElementById("pivot-source-range");
    var createPivotBtn = document.getElementById("create-pivot-btn");
    var createPivotCancelBtn = document.getElementById("create-pivot-cancel-btn");
    var createPivotError = document.getElementById("create-pivot-error");
    var pivotEditor = document.getElementById("pivot-editor");
    var pivotRows = document.getElementById("pivot-rows");
    var pivotColumns = document.getElementById("pivot-columns");
    var pivotValues = document.getElementById("pivot-values");
    var pivotSummarize = document.getElementById("pivot-summarize");
    var pivotApplyBtn = document.getElementById("pivot-apply-btn");
    var pivotError = document.getElementById("pivot-error");
    var pivotResultToolbar = document.getElementById("pivot-result-toolbar");
    var refreshPivotBtn = document.getElementById("refresh-pivot-btn");
    var pivotResultError = document.getElementById("pivot-result-error");
    var targetColumnIndex = null;
    var targetRowIndex = null;
    var currentDropdown = null;
    var clipboard = null;
    var activeWs = null;
    var dragging = null;
    var dragWorkbook = null;
    var dragWorksheet = null;
    var filterColumn = null;
    var filterRegion = null;
    var currentCell = null;
    var currentCellEl = null;
    var committedValue = "";
    var editing = false;
    var cellError = document.getElementById("cell-error");
    var pivotSourceWs = null;
    var pivotSourceRegion = null;
    var pivotConfig = null;
    var undoStack = [];
    var redoStack = [];

    if (!id) {
      nameEl.textContent = "No workbook selected";
      return;
    }


    var currentWorkbook = null;

    var undoBtn = document.getElementById("undo-btn");
    var redoBtn = document.getElementById("redo-btn");
    if (undoBtn) undoBtn.addEventListener("click", undo);
    if (redoBtn) redoBtn.addEventListener("click", redo);

    document.addEventListener("keydown", function (ev) {
      var mod = ev.ctrlKey || ev.metaKey;
      if (!mod) return;
      var key = ev.key.toLowerCase();
      if (key === "z") {
        ev.preventDefault();
        if (ev.shiftKey) {
          redo();
        } else {
          undo();
        }
      } else if (key === "y") {
        ev.preventDefault();
        redo();
      } else if (key === "c" || key === "x" || key === "v") {
        // Grid commands work at the document level: copy/cut/paste the
        // selected range regardless of where focus sits. When focus is inside
        // the grid, the grid's own keydown handler performs the action; here
        // we only act when focus is elsewhere (e.g. the formula bar).
        var target = ev.target;
        var inGrid = target && target.closest ? target.closest("#grid") != null : false;
        if (inGrid) return;
        ev.preventDefault();
        if (key === "c") {
          copySelection("copy");
        } else if (key === "x") {
          copySelection("cut");
        } else if (key === "v") {
          if (clipboard) {
            pasteFromInternalClipboard();
          } else {
            pasteFromClipboard();
          }
        }
      }
    });

    fetch("/api/workbooks/" + encodeURIComponent(id))
      .then(function (r) {
        if (!r.ok) throw new Error("not found");
        return r.json();
      })
      .then(function (wb) {
        currentWorkbook = wb;
        nameEl.textContent = wb.name;
        updatedEl.textContent = "Last updated: " + formatDate(wb.lastUpdated);
        document.title = wb.name + " - Editor";
        // Always open on the first worksheet so the seeded data is visible
        // regardless of which worksheet was active in a prior session.
        wb.worksheets.forEach(function (w, i) {
          w.active = i === 0;
        });
        renderTabs(wb);
        renderGrid(wb);
        var ws = wb.worksheets[0];
        restoreSelection(ws);
        if (ws && ws.filters && Object.keys(ws.filters).length > 0) {
          filterRegion = detectRegion(ws);
          if (filterRegion) {
            renderFilterToolbar(ws);
            filterToolbar.classList.remove("hidden");
          }
        }
        if (ws && ws.pivot) {
          populatePivotEditor(ws);
          pivotEditor.classList.remove("hidden");
          pivotResultToolbar.classList.remove("hidden");
          pivotResultError.textContent = "";
        }
        updateUndoRedoButtons();
      })
      .catch(function () {
        nameEl.textContent = "Workbook not found";
      });

    renameBtn.addEventListener("click", function (ev) {
      ev.preventDefault();
      if (!currentWorkbook) return;
      renameInput.value = currentWorkbook.name;
      renameError.textContent = "";
      renameDialog.classList.remove("hidden");
      renameInput.focus();
    });

    renameCancelBtn.addEventListener("click", function () {
      renameDialog.classList.add("hidden");
      renameError.textContent = "";
    });

    renameSaveBtn.addEventListener("click", function () {
      var newName = renameInput.value.trim();
      if (!newName) {
        renameError.textContent = "Workbook name cannot be empty";
        return;
      }
      fetch("/api/workbooks/" + encodeURIComponent(id), {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName }),
      })
        .then(function (r) {
          if (!r.ok) {
            throw new Error("save failed");
          }
          return r.json();
        })
        .then(function (wb) {
          currentWorkbook = wb;
          nameEl.textContent = wb.name;
          document.title = wb.name + " - Editor";
          renameDialog.classList.add("hidden");
          renameError.textContent = "";
        })
        .catch(function () {
          renameError.textContent = "Could not save the workbook name.";
        });
    });

    exportBtn.addEventListener("click", function () {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var rows = ws.rows || 0;
      var cols = ws.cols || 0;
      var lines = [];
      for (var r = 0; r < rows; r++) {
        var line = [];
        for (var c = 0; c < cols; c++) {
          var coord = colName(c) + (r + 1);
          line.push(csvEscape(cellDisplayValue(ws, coord)));
        }
        lines.push(line.join(","));
      }
      var csv = lines.join("\n");
      var blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = (currentWorkbook.name || "worksheet") + ".csv";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });

    renameWsMenuItem.addEventListener("click", function () {
      worksheetMenu.classList.add("hidden");
      if (!activeWs) return;
      renameWsInput.value = activeWs.name;
      renameWsError.textContent = "";
      renameWsDialog.classList.remove("hidden");
      renameWsInput.focus();
    });

    deleteWsMenuItem.addEventListener("click", function () {
      worksheetMenu.classList.add("hidden");
      if (!currentWorkbook || !activeWs) return;
      // If only one worksheet remains, do not open a confirmation dialog.
      if (currentWorkbook.worksheets.length <= 1) {
        addWsError.textContent = "A workbook must contain at least one worksheet";
        return;
      }
      deleteWsDescription.textContent = "Delete worksheet \"" + activeWs.name + "\"?";
      deleteWsError.textContent = "";
      deleteWsDialog.classList.remove("hidden");
    });

    deleteWsCancelBtn.addEventListener("click", function () {
      deleteWsDialog.classList.add("hidden");
      deleteWsError.textContent = "";
    });

    deleteWsConfirmBtn.addEventListener("click", function () {
      if (!currentWorkbook || !activeWs) return;
      var target = activeWs;
      var idx = currentWorkbook.worksheets.indexOf(target);
      if (idx < 0) {
        deleteWsError.textContent = "Could not delete the worksheet.";
        return;
      }
      // Re-check constraints at confirmation time.
      if (currentWorkbook.worksheets.length <= 1) {
        deleteWsDialog.classList.add("hidden");
        addWsError.textContent = "A workbook must contain at least one worksheet";
        return;
      }
      var isPivotSource = currentWorkbook.worksheets.some(function (w) {
        return w !== target && w.pivot && w.pivot.sourceWorksheet === target.name;
      });
      if (isPivotSource) {
        deleteWsDialog.classList.add("hidden");
        deleteWsError.textContent = "";
        addWsError.textContent = "Please delete or rebuild dependent pivot tables first";
        return;
      }
      var prevWorksheets = currentWorkbook.worksheets;
      var prevLastUpdated = currentWorkbook.lastUpdated;
      // Determine the adjacent worksheet to become active.
      var remaining = currentWorkbook.worksheets.filter(function (w) {
        return w !== target;
      });
      var nextActive = remaining[Math.min(idx, remaining.length - 1)];
      remaining.forEach(function (w) {
        w.active = w === nextActive;
      });
      pushUndo();
      currentWorkbook.worksheets = remaining;
      currentWorkbook.lastUpdated = new Date().toISOString();
      deleteWsDialog.classList.add("hidden");
      deleteWsError.textContent = "";
      addWsError.textContent = "";
      activeWs = nextActive;
      renderTabs(currentWorkbook);
      renderGrid(currentWorkbook);
      restoreSelection(nextActive);
      // Close per-worksheet UI that may reference the deleted worksheet.
      filterToolbar.classList.add("hidden");
      filterHeaderButtons.innerHTML = "";
      pivotEditor.classList.add("hidden");
      pivotResultToolbar.classList.add("hidden");
      pivotResultError.textContent = "";
      saveWorkbook(currentWorkbook).catch(function () {
        currentWorkbook.worksheets = prevWorksheets;
        currentWorkbook.lastUpdated = prevLastUpdated;
        renderTabs(currentWorkbook);
        renderGrid(currentWorkbook);
        deleteWsDialog.classList.remove("hidden");
        deleteWsError.textContent = "Could not delete the worksheet.";
      });
    });

    renameWsCancelBtn.addEventListener("click", function () {
      renameWsDialog.classList.add("hidden");
      renameWsError.textContent = "";
    });

    renameWsSaveBtn.addEventListener("click", function () {
      if (!activeWs || !currentWorkbook) return;
      var newName = renameWsInput.value.trim();
      if (!newName) {
        renameWsError.textContent = "Worksheet name cannot be empty";
        return;
      }
      var duplicate = currentWorkbook.worksheets.some(function (w) {
        return w !== activeWs && w.name === newName;
      });
      if (duplicate) {
        renameWsError.textContent = "Worksheet name already exists";
        return;
      }
      var originalName = activeWs.name;
      pushUndo();
      activeWs.name = newName;
      currentWorkbook.lastUpdated = new Date().toISOString();
      renderTabs(currentWorkbook);
      renderGrid(currentWorkbook);
      restoreSelection(activeWs);
      renameWsDialog.classList.add("hidden");
      renameWsError.textContent = "";
      saveWorkbook(currentWorkbook).catch(function () {
        activeWs.name = originalName;
        currentWorkbook.lastUpdated = new Date().toISOString();
        renderTabs(currentWorkbook);
        renderGrid(currentWorkbook);
        restoreSelection(activeWs);
        renameWsDialog.classList.remove("hidden");
        renameWsError.textContent = "Could not save the worksheet name.";
      });
    });

    dataBtn.addEventListener("click", function (ev) {
      ev.stopPropagation();
      if (dataMenu.classList.contains("hidden")) {
        dataMenu.classList.remove("hidden");
      } else {
        dataMenu.classList.add("hidden");
      }
    });

    createFilterItem.addEventListener("click", function () {
      dataMenu.classList.add("hidden");
      if (!currentWorkbook) return;
      var ws = currentWorkbook.worksheets.find(function (w) {
        return w.active;
      }) || currentWorkbook.worksheets[0];
      if (!ws) return;
      var region = detectRegion(ws);
      if (!region || region.headers.length === 0) {
        filterError.textContent = "No data region with headers found in the active worksheet.";
        filterToolbar.classList.remove("hidden");
        filterHeaderButtons.innerHTML = "";
        return;
      }
      filterRegion = region;
      filterError.textContent = "";
      renderFilterToolbar(ws);
      filterToolbar.classList.remove("hidden");
    });

    clearFilterItem.addEventListener("click", function () {
      dataMenu.classList.add("hidden");
      if (!currentWorkbook) return;
      var ws = currentWorkbook.worksheets.find(function (w) {
        return w.active;
      }) || currentWorkbook.worksheets[0];
      if (!ws) return;
      pushUndo();
      ws.filters = {};
      currentWorkbook.lastUpdated = new Date().toISOString();
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      if (filterRegion) {
        renderFilterToolbar(ws);
      }
      saveWorkbook(currentWorkbook);
    });

    filterClearSelection.addEventListener("click", function () {
      var boxes = filterValues.querySelectorAll('input[type="checkbox"]');
      for (var i = 0; i < boxes.length; i++) {
        boxes[i].checked = false;
      }
    });

    function collectSelectedValues() {
      var selected = [];
      var boxes = filterValues.querySelectorAll('input[type="checkbox"]');
      for (var i = 0; i < boxes.length; i++) {
        if (boxes[i].checked) {
          selected.push(boxes[i].value);
        }
      }
      return selected;
    }

    function closeFilterDialog() {
      filterDialog.classList.add("hidden");
      filterValues.innerHTML = "";
    }

    function applyFilterValues() {
      if (!currentWorkbook || filterColumn === null) return;
      var ws = currentWorkbook.worksheets.find(function (w) {
        return w.active;
      }) || currentWorkbook.worksheets[0];
      if (!ws) return;
      var selected = collectSelectedValues();
      var type = filterCondition.value;
      var value = filterValueInput.value;
      if (type === "Greater than" || type === "Before") {
        if (value.trim() === "") {
          filterError.textContent = "A value is required for this condition.";
          return;
        }
      }
      if (!ws.filters) ws.filters = {};
      if (!ws.filters[filterColumn]) ws.filters[filterColumn] = {};
      pushUndo();
      ws.filters[filterColumn].values = selected;
      if (type === "Text contains" && value.trim() === "") {
        ws.filters[filterColumn].condition = null;
      } else {
        ws.filters[filterColumn].condition = { type: type, value: value };
      }
      currentWorkbook.lastUpdated = new Date().toISOString();
      closeFilterDialog();
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      if (filterRegion) renderFilterToolbar(ws);
      saveWorkbook(currentWorkbook);
    }

    function applyFilterCondition() {
      if (!currentWorkbook || filterColumn === null) return;
      var ws = currentWorkbook.worksheets.find(function (w) {
        return w.active;
      }) || currentWorkbook.worksheets[0];
      if (!ws) return;
      var type = filterCondition.value;
      var value = filterValueInput.value;
      if (type === "Greater than" || type === "Before") {
        if (value.trim() === "") {
          filterError.textContent = "A value is required for this condition.";
          return;
        }
      }
      var selected = collectSelectedValues();
      if (!ws.filters) ws.filters = {};
      if (!ws.filters[filterColumn]) ws.filters[filterColumn] = {};
      pushUndo();
      ws.filters[filterColumn].values = selected;
      if (type === "Text contains" && value.trim() === "") {
        ws.filters[filterColumn].condition = null;
      } else {
        ws.filters[filterColumn].condition = { type: type, value: value };
      }
      currentWorkbook.lastUpdated = new Date().toISOString();
      closeFilterDialog();
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      if (filterRegion) renderFilterToolbar(ws);
      saveWorkbook(currentWorkbook);
    }

    filterValuesApply.addEventListener("click", applyFilterValues);
    filterConditionApply.addEventListener("click", applyFilterCondition);

    filterCancelBtn.addEventListener("click", function () {
      filterDialog.classList.add("hidden");
      filterValues.innerHTML = "";
    });

    dataValidationItem.addEventListener("click", function () {
      dataMenu.classList.add("hidden");
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var selRect = parseRect(ws.selection);
      if (!selRect) {
        validationError.textContent = "Please select a range first.";
        validationDialog.classList.remove("hidden");
        return;
      }
      var existing = ws.validation;
      if (existing) {
        validationRuleType.value = existing.type === "dropdown" ? "Dropdown" : "Number range";
        validationAllowedValues.value = (existing.values || []).join(", ");
        validationMin.value = existing.min !== undefined ? String(existing.min) : "";
        validationMax.value = existing.max !== undefined ? String(existing.max) : "";
        validationDeleteBtn.style.display = "";
      } else {
        validationRuleType.value = "Dropdown";
        validationAllowedValues.value = "";
        validationMin.value = "";
        validationMax.value = "";
        validationDeleteBtn.style.display = "none";
      }
      updateValidationFields();
      validationError.textContent = "";
      validationDialog.classList.remove("hidden");
    });

    validationRuleType.addEventListener("change", function () {
      updateValidationFields();
    });

    function updateValidationFields() {
      var type = validationRuleType.value;
      if (type === "Dropdown") {
        validationAllowedField.style.display = "";
        validationMinField.style.display = "none";
        validationMaxField.style.display = "none";
      } else {
        validationAllowedField.style.display = "none";
        validationMinField.style.display = "";
        validationMaxField.style.display = "";
      }
    }

    validationSaveBtn.addEventListener("click", function () {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var selRect = parseRect(ws.selection);
      if (!selRect) {
        validationError.textContent = "Please select a range first.";
        return;
      }
      var range = formatCoord(selRect.top, selRect.left) + ":" + formatCoord(selRect.bottom, selRect.right);
      var type = validationRuleType.value;
      var newValidation;
      if (type === "Dropdown") {
        var raw = validationAllowedValues.value;
        var values = raw.split(",").map(function (s) {
          return s.trim();
        }).filter(function (s) {
          return s !== "";
        });
        if (values.length === 0) {
          validationError.textContent = "Please enter at least one allowed value.";
          return;
        }
        newValidation = { range: range, type: "dropdown", values: values };
      } else {
        var minStr = validationMin.value.trim();
        var maxStr = validationMax.value.trim();
        if (minStr === "" || maxStr === "") {
          validationError.textContent = "Please enter both minimum and maximum values.";
          return;
        }
        var min = Number(minStr);
        var max = Number(maxStr);
        if (isNaN(min) || isNaN(max)) {
          validationError.textContent = "Please enter valid numeric minimum and maximum values.";
          return;
        }
        if (min > max) {
          validationError.textContent = "Minimum must be less than or equal to maximum.";
          return;
        }
        newValidation = { range: range, type: "number-range", min: min, max: max };
      }
      var prevValidation = ws.validation;
      pushUndo();
      ws.validation = newValidation;
      currentWorkbook.lastUpdated = new Date().toISOString();
      validationDialog.classList.add("hidden");
      validationError.textContent = "";
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      saveWorkbook(currentWorkbook).catch(function () {
        ws.validation = prevValidation;
        currentWorkbook.lastUpdated = new Date().toISOString();
        renderGrid(currentWorkbook);
        validationDialog.classList.remove("hidden");
        validationError.textContent = "Could not save the data validation rule.";
      });
    });

    validationDeleteBtn.addEventListener("click", function () {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var prevValidation = ws.validation;
      pushUndo();
      delete ws.validation;
      currentWorkbook.lastUpdated = new Date().toISOString();
      validationDialog.classList.add("hidden");
      validationError.textContent = "";
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      saveWorkbook(currentWorkbook).catch(function () {
        ws.validation = prevValidation;
        currentWorkbook.lastUpdated = new Date().toISOString();
        renderGrid(currentWorkbook);
        validationDialog.classList.remove("hidden");
        validationError.textContent = "Could not delete the data validation rule.";
      });
    });

    validationCancelBtn.addEventListener("click", function () {
      validationDialog.classList.add("hidden");
      validationError.textContent = "";
    });

    createPivotItem.addEventListener("click", function () {
      dataMenu.classList.add("hidden");
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var region = detectRegion(ws);
      if (!region || region.headers.length === 0) {
        createPivotError.textContent = "No data region with headers found in the active worksheet.";
        createPivotDialog.classList.remove("hidden");
        return;
      }
      pivotSourceWs = ws;
      pivotSourceRegion = region;
      var rangeText = formatCoord(0, 0) + ":" + formatCoord(region.dataRows.length, region.headers.length - 1);
      pivotSourceRange.textContent = "Source range: " + rangeText;
      createPivotError.textContent = "";
      createPivotDialog.classList.remove("hidden");
    });

    createPivotCancelBtn.addEventListener("click", function () {
      createPivotDialog.classList.add("hidden");
      createPivotError.textContent = "";
    });

    createPivotBtn.addEventListener("click", function () {
      if (!currentWorkbook || !pivotSourceWs || !pivotSourceRegion) return;
      var dest = document.querySelector('input[name="pivot-destination"]:checked');
      if (!dest || dest.value !== "new") {
        createPivotError.textContent = "Please choose a destination worksheet.";
        return;
      }
      // Determine the next unused PivotN name.
      var used = {};
      currentWorkbook.worksheets.forEach(function (w) {
        used[w.name] = true;
      });
      var n = 1;
      while (used["Pivot" + n]) n++;
      var pivotName = "Pivot" + n;
      var pivotWs = {
        name: pivotName,
        active: false,
        rows: 0,
        cols: 0,
        cells: {},
        selection: { start: "A1", end: "A1" },
        pivot: {
          sourceWorksheet: pivotSourceWs.name,
          sourceRange: formatCoord(0, 0) + ":" + formatCoord(pivotSourceRegion.dataRows.length, pivotSourceRegion.headers.length - 1),
          rowField: null,
          columnField: null,
          valueField: null,
          summarize: "SUM",
        },
      };
      pushUndo();
      currentWorkbook.worksheets.push(pivotWs);
      currentWorkbook.lastUpdated = new Date().toISOString();
      createPivotDialog.classList.add("hidden");
      createPivotError.textContent = "";
      // Switch to the new pivot worksheet.
      currentWorkbook.worksheets.forEach(function (w) {
        w.active = w === pivotWs;
      });
      renderTabs(currentWorkbook);
      renderGrid(currentWorkbook);
      restoreSelection(pivotWs);
      // Populate the pivot editor with source headers.
      populatePivotEditor(pivotWs);
      pivotEditor.classList.remove("hidden");
      pivotResultToolbar.classList.remove("hidden");
      pivotResultError.textContent = "";
      saveWorkbook(currentWorkbook);
    });

    pivotApplyBtn.addEventListener("click", function () {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws || !ws.pivot) return;
      var rowField = pivotRows.value;
      var columnField = pivotColumns.value;
      var valueField = pivotValues.value;
      var summarize = pivotSummarize.value;
      if (!rowField) {
        pivotError.textContent = "Please select a row field.";
        return;
      }
      if (!valueField) {
        pivotError.textContent = "Please select a value field.";
        return;
      }
      var prevConfig = ws.pivot;
      var prevCells = ws.cells;
      var prevRows = ws.rows;
      var prevCols = ws.cols;
      var prevLastUpdated = currentWorkbook.lastUpdated;
      pushUndo();
      ws.pivot.rowField = rowField;
      ws.pivot.columnField = columnField;
      ws.pivot.valueField = valueField;
      ws.pivot.summarize = summarize;
      var result = computePivot(ws);
      if (result.error) {
        pivotError.textContent = result.error;
        ws.pivot = prevConfig;
        ws.cells = prevCells;
        ws.rows = prevRows;
        ws.cols = prevCols;
        currentWorkbook.lastUpdated = prevLastUpdated;
        return;
      }
      ws.cells = result.cells;
      ws.rows = result.rows;
      ws.cols = result.cols;
      currentWorkbook.lastUpdated = new Date().toISOString();
      pivotError.textContent = "";
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      saveWorkbook(currentWorkbook).catch(function () {
        ws.pivot = prevConfig;
        ws.cells = prevCells;
        ws.rows = prevRows;
        ws.cols = prevCols;
        currentWorkbook.lastUpdated = prevLastUpdated;
        renderGrid(currentWorkbook);
        pivotError.textContent = "Could not save the pivot table.";
      });
    });

    refreshPivotBtn.addEventListener("click", function () {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws || !ws.pivot) return;
      var sourceWs = currentWorkbook.worksheets.find(function (w) {
        return w.name === ws.pivot.sourceWorksheet;
      });
      if (!sourceWs) {
        pivotResultError.textContent = "Pivot field is no longer available. Select a new field.";
        return;
      }
      var region = detectRegion(sourceWs);
      if (!region || region.headers.length === 0) {
        pivotResultError.textContent = "Pivot field is no longer available. Select a new field.";
        return;
      }
      // Verify the selected fields still exist in the source headers.
      var headerNames = region.headers.map(function (h) {
        return h.name;
      });
      if (ws.pivot.rowField && headerNames.indexOf(ws.pivot.rowField) < 0) {
        pivotResultError.textContent = "Pivot field is no longer available. Select a new field.";
        return;
      }
      if (ws.pivot.columnField && headerNames.indexOf(ws.pivot.columnField) < 0) {
        pivotResultError.textContent = "Pivot field is no longer available. Select a new field.";
        return;
      }
      if (ws.pivot.valueField && headerNames.indexOf(ws.pivot.valueField) < 0) {
        pivotResultError.textContent = "Pivot field is no longer available. Select a new field.";
        return;
      }
      var prevCells = ws.cells;
      var prevRows = ws.rows;
      var prevCols = ws.cols;
      var prevLastUpdated = currentWorkbook.lastUpdated;
      var result = computePivot(ws);
      if (result.error) {
        pivotResultError.textContent = result.error;
        ws.cells = prevCells;
        ws.rows = prevRows;
        ws.cols = prevCols;
        currentWorkbook.lastUpdated = prevLastUpdated;
        return;
      }
      pushUndo();
      ws.cells = result.cells;
      ws.rows = result.rows;
      ws.cols = result.cols;
      currentWorkbook.lastUpdated = new Date().toISOString();
      pivotResultError.textContent = "";
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      saveWorkbook(currentWorkbook).catch(function () {
        ws.cells = prevCells;
        ws.rows = prevRows;
        ws.cols = prevCols;
        currentWorkbook.lastUpdated = prevLastUpdated;
        renderGrid(currentWorkbook);
        pivotResultError.textContent = "Could not refresh the pivot table.";
      });
    });

    function populatePivotEditor(pivotWs) {
      var sourceWs = currentWorkbook.worksheets.find(function (w) {
        return w.name === pivotWs.pivot.sourceWorksheet;
      });
      if (!sourceWs) return;
      var region = detectRegion(sourceWs);
      if (!region) return;
      var headers = region.headers.map(function (h) {
        return h.name;
      });
      pivotRows.innerHTML = "";
      pivotColumns.innerHTML = "";
      pivotValues.innerHTML = "";
      var emptyRow = document.createElement("option");
      emptyRow.value = "";
      emptyRow.textContent = "";
      pivotRows.appendChild(emptyRow);
      var emptyCol = document.createElement("option");
      emptyCol.value = "";
      emptyCol.textContent = "";
      pivotColumns.appendChild(emptyCol);
      headers.forEach(function (h) {
        var o1 = document.createElement("option");
        o1.value = h;
        o1.textContent = h;
        pivotRows.appendChild(o1);
        var o2 = document.createElement("option");
        o2.value = h;
        o2.textContent = h;
        pivotColumns.appendChild(o2);
        var o3 = document.createElement("option");
        o3.value = h;
        o3.textContent = h;
        pivotValues.appendChild(o3);
      });
      if (pivotWs.pivot.rowField) pivotRows.value = pivotWs.pivot.rowField;
      if (pivotWs.pivot.columnField) pivotColumns.value = pivotWs.pivot.columnField;
      if (pivotWs.pivot.valueField) pivotValues.value = pivotWs.pivot.valueField;
      pivotSummarize.value = pivotWs.pivot.summarize || "SUM";
    }

    function computePivot(pivotWs) {
      var sourceWs = currentWorkbook.worksheets.find(function (w) {
        return w.name === pivotWs.pivot.sourceWorksheet;
      });
      if (!sourceWs) {
        return { error: "Pivot field is no longer available. Select a new field." };
      }
      var region = detectRegion(sourceWs);
      if (!region || region.headers.length === 0) {
        return { error: "Pivot field is no longer available. Select a new field." };
      }
      var headerNames = region.headers.map(function (h) {
        return h.name;
      });
      var rowField = pivotWs.pivot.rowField;
      var columnField = pivotWs.pivot.columnField;
      var valueField = pivotWs.pivot.valueField;
      var summarize = pivotWs.pivot.summarize || "SUM";
      if (rowField && headerNames.indexOf(rowField) < 0) {
        return { error: "Pivot field is no longer available. Select a new field." };
      }
      if (columnField && headerNames.indexOf(columnField) < 0) {
        return { error: "Pivot field is no longer available. Select a new field." };
      }
      if (valueField && headerNames.indexOf(valueField) < 0) {
        return { error: "Pivot field is no longer available. Select a new field." };
      }
      var rowCol = null;
      var colCol = null;
      var valCol = null;
      region.headers.forEach(function (h) {
        if (h.name === rowField) rowCol = h.col;
        if (h.name === columnField) colCol = h.col;
        if (h.name === valueField) valCol = h.col;
      });
      if (rowCol === null || valCol === null) {
        return { error: "Pivot field is no longer available. Select a new field." };
      }
      var cells = sourceWs.cells || {};
      // Collect data records.
      var records = [];
      region.dataRows.forEach(function (r) {
        var rec = {};
        region.headers.forEach(function (h) {
          var coord = colName(h.col) + (r + 1);
          rec[h.name] = cells[coord] !== undefined ? cells[coord] : "";
        });
        records.push(rec);
      });
      // Global check: for SUM/AVERAGE, the value field must contain at least
      // one parseable number across all records.
      if (summarize === "SUM" || summarize === "AVERAGE") {
        var hasNumeric = false;
        records.forEach(function (rec) {
          var v = rec[valueField];
          if (v === undefined || v === null || String(v).trim() === "") return;
          if (!isNaN(Number(v))) hasNumeric = true;
        });
        if (!hasNumeric) {
          return { error: "Value field requires numeric values" };
        }
      }
      // Determine row values in order of first appearance.
      var rowValues = [];
      var rowSeen = {};
      records.forEach(function (rec) {
        var v = String(rec[rowField] === undefined ? "" : rec[rowField]);
        if (!rowSeen[v]) {
          rowSeen[v] = true;
          rowValues.push(v);
        }
      });
      // Determine column values in order of first appearance (if column field selected).
      var colValues = [];
      var colSeen = {};
      if (columnField) {
        records.forEach(function (rec) {
          var v = String(rec[columnField] === undefined ? "" : rec[columnField]);
          if (!colSeen[v]) {
            colSeen[v] = true;
            colValues.push(v);
          }
        });
      }
      // Build the result grid.
      var resultCells = {};
      var resultRows = 0;
      var resultCols = 0;
      var summarizeLabel = summarize === "SUM" ? "SUM" : summarize === "COUNT" ? "COUNT" : "AVERAGE";
      if (!columnField) {
        // No column field: A1 = row field name, B1 = "<method> of <value field>".
        resultCells.A1 = rowField;
        resultCells.B1 = summarizeLabel + " of " + valueField;
        resultCols = 2;
        var rIdx = 1;
        rowValues.forEach(function (rv) {
          var coord = "A" + (rIdx + 1);
          resultCells[coord] = rv;
          var agg = aggregate(records, rowField, rv, null, null, valueField, summarize);
          if (agg.error) return { error: agg.error };
          resultCells["B" + (rIdx + 1)] = agg.value;
          rIdx++;
        });
        // Grand total row.
        var totalAgg = aggregate(records, null, null, null, null, valueField, summarize);
        if (totalAgg.error) return { error: totalAgg.error };
        resultCells["A" + (rIdx + 1)] = "Grand Total";
        resultCells["B" + (rIdx + 1)] = totalAgg.value;
        resultRows = rIdx + 1;
      } else {
        // Column field selected: A1 = row field name, column values from B1 onward.
        resultCells.A1 = rowField;
        colValues.forEach(function (cv, i) {
          resultCells[colName(i + 1) + "1"] = cv;
        });
        resultCells[colName(colValues.length + 1) + "1"] = "Grand Total";
        resultCols = colValues.length + 2;
        var rIdx2 = 1;
        rowValues.forEach(function (rv) {
          resultCells["A" + (rIdx2 + 1)] = rv;
          colValues.forEach(function (cv, i) {
            var agg = aggregate(records, rowField, rv, columnField, cv, valueField, summarize);
            if (agg.error) return { error: agg.error };
            resultCells[colName(i + 1) + (rIdx2 + 1)] = agg.value;
          });
          // Row grand total.
          var rowTotal = aggregate(records, rowField, rv, null, null, valueField, summarize);
          if (rowTotal.error) return { error: rowTotal.error };
          resultCells[colName(colValues.length + 1) + (rIdx2 + 1)] = rowTotal.value;
          rIdx2++;
        });
        // Grand total row.
        resultCells["A" + (rIdx2 + 1)] = "Grand Total";
        colValues.forEach(function (cv, i) {
          var agg = aggregate(records, null, null, columnField, cv, valueField, summarize);
          if (agg.error) return { error: agg.error };
          resultCells[colName(i + 1) + (rIdx2 + 1)] = agg.value;
        });
        var grandTotal = aggregate(records, null, null, null, null, valueField, summarize);
        if (grandTotal.error) return { error: grandTotal.error };
        resultCells[colName(colValues.length + 1) + (rIdx2 + 1)] = grandTotal.value;
        resultRows = rIdx2 + 1;
      }
      return { cells: resultCells, rows: resultRows, cols: resultCols };
    }

    function aggregate(records, rowField, rowValue, colField, colValue, valueField, summarize) {
      var matching = records.filter(function (rec) {
        if (rowField && String(rec[rowField]) !== String(rowValue)) return false;
        if (colField && String(rec[colField]) !== String(colValue)) return false;
        return true;
      });
      if (summarize === "COUNT") {
        var count = 0;
        matching.forEach(function (rec) {
          var v = rec[valueField];
          if (v !== undefined && v !== null && String(v) !== "") count++;
        });
        return { value: String(count) };
      }
      // SUM or AVERAGE: only parseable numbers count.
      var nums = [];
      matching.forEach(function (rec) {
        var v = rec[valueField];
        if (v === undefined || v === null || String(v).trim() === "") return;
        var n = Number(v);
        if (!isNaN(n)) nums.push(n);
      });
      if (nums.length === 0) {
        return { value: "0" };
      }
      if (summarize === "SUM") {
        var sum = 0;
        nums.forEach(function (n) {
          sum += n;
        });
        return { value: String(sum) };
      }
      if (summarize === "AVERAGE") {
        var s = 0;
        nums.forEach(function (n) {
          s += n;
        });
        return { value: String(Math.round((s / nums.length) * 1000000) / 1000000) };
      }
      return { value: "0" };
    }

    gridEl.addEventListener("contextmenu", function (ev) {
      ev.preventDefault();
      if (!currentWorkbook) return;
      var rh = ev.target && ev.target.closest ? ev.target.closest(".row-header") : null;
      if (rh) {
        var r0 = Number(rh.getAttribute("data-row"));
        var ws = activeWorksheet();
        if (ws) {
          targetRowIndex = r0;
          rowError.textContent = "";
          rowMenu.style.left = ev.clientX + "px";
          rowMenu.style.top = ev.clientY + "px";
          rowMenu.classList.remove("hidden");
        }
        return;
      }
      var ch = ev.target && ev.target.closest ? ev.target.closest(".col-header") : null;
      if (ch) {
        var c0 = Number(ch.getAttribute("data-col"));
        var ws2 = activeWorksheet();
        if (ws2) {
          targetColumnIndex = c0;
          columnError.textContent = "";
          columnMenu.style.left = ev.clientX + "px";
          columnMenu.style.top = ev.clientY + "px";
          columnMenu.classList.remove("hidden");
        }
        return;
      }
      var cell = ev.target && ev.target.closest ? ev.target.closest(".data-cell") : null;
      if (cell) {
        var coord = cell.getAttribute("data-coord");
        var r0 = Number(cell.getAttribute("data-row"));
        var c0 = Number(cell.getAttribute("data-col"));
        var ws = activeWorksheet();
        if (ws) {
          var selRect = parseRect(ws.selection);
          var inSel = selRect && r0 >= selRect.top && r0 <= selRect.bottom && c0 >= selRect.left && c0 <= selRect.right;
          if (!inSel) {
            startSelection(currentWorkbook, ws, r0, c0);
          }
          currentCell = coord;
          currentCellEl = cell;
          committedValue = (ws.cells && ws.cells[coord]) || "";
          editing = false;
          formulaEl.value = committedValue;
        }
      }
      gridMenu.style.left = ev.clientX + "px";
      gridMenu.style.top = ev.clientY + "px";
      gridMenu.classList.remove("hidden");
    });

    copyMenuItem.addEventListener("click", function () {
      gridMenu.classList.add("hidden");
      copySelection("copy");
    });

    cutMenuItem.addEventListener("click", function () {
      gridMenu.classList.add("hidden");
      copySelection("cut");
    });

    pasteMenuItem.addEventListener("click", function () {
      gridMenu.classList.add("hidden");
      if (clipboard) {
        pasteFromInternalClipboard();
      } else {
        pasteFromClipboard();
      }
    });

    insertRowAboveItem.addEventListener("click", function () {
      rowMenu.classList.add("hidden");
      if (targetRowIndex === null || !currentWorkbook) return;
      insertRow(targetRowIndex);
    });

    insertRowBelowItem.addEventListener("click", function () {
      rowMenu.classList.add("hidden");
      if (targetRowIndex === null || !currentWorkbook) return;
      insertRow(targetRowIndex + 1);
    });

    deleteRowItem.addEventListener("click", function () {
      rowMenu.classList.add("hidden");
      if (targetRowIndex === null || !currentWorkbook) return;
      deleteRow(targetRowIndex);
    });

    insertColumnLeftItem.addEventListener("click", function () {
      columnMenu.classList.add("hidden");
      if (targetColumnIndex === null || !currentWorkbook) return;
      insertColumn(targetColumnIndex);
    });

    insertColumnRightItem.addEventListener("click", function () {
      columnMenu.classList.add("hidden");
      if (targetColumnIndex === null || !currentWorkbook) return;
      insertColumn(targetColumnIndex + 1);
    });

    deleteColumnItem.addEventListener("click", function () {
      columnMenu.classList.add("hidden");
      if (targetColumnIndex === null || !currentWorkbook) return;
      deleteColumn(targetColumnIndex);
    });

    gridEl.addEventListener("keydown", function (ev) {
      if (!currentWorkbook) return;
      var mod = ev.ctrlKey || ev.metaKey;
      if (!mod) return;
      var key = ev.key.toLowerCase();
      if (key === "c") {
        ev.preventDefault();
        copySelection("copy");
      } else if (key === "x") {
        ev.preventDefault();
        copySelection("cut");
      } else if (key === "v") {
        ev.preventDefault();
        if (clipboard) {
          pasteFromInternalClipboard();
        } else {
          pasteFromClipboard();
        }
      }
    });

    document.addEventListener("paste", function (ev) {
      if (!currentWorkbook || !currentCell) return;
      var target = ev.target;
      var inGrid = target && target.closest ? target.closest("#grid") != null : false;
      if (!inGrid) return;
      var text = ev.clipboardData ? ev.clipboardData.getData("text") : "";
      if (text) {
        ev.preventDefault();
        applyPaste(text);
      }
    });

    formulaEl.addEventListener("input", function () {
      if (!currentCell || !currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var raw = formulaEl.value;
      editing = true;
      if (currentCellEl) {
        if (isFormula(raw)) {
          currentCellEl.textContent = evaluateFormula(raw, ws);
        } else {
          currentCellEl.textContent = raw;
        }
      }
    });

    formulaEl.addEventListener("keydown", function (ev) {
      if (ev.key === "Enter") {
        ev.preventDefault();
        commitCell();
      } else if (ev.key === "Escape") {
        ev.preventDefault();
        cancelCell();
      }
    });

    document.addEventListener("click", function (ev) {
      if (!worksheetMenu.classList.contains("hidden") && !worksheetMenu.contains(ev.target)) {
        worksheetMenu.classList.add("hidden");
      }
      if (!dataMenu.classList.contains("hidden") && !dataMenu.contains(ev.target) && ev.target !== dataBtn) {
        dataMenu.classList.add("hidden");
      }
      if (!gridMenu.classList.contains("hidden") && !gridMenu.contains(ev.target)) {
        gridMenu.classList.add("hidden");
      }
      if (!rowMenu.classList.contains("hidden") && !rowMenu.contains(ev.target)) {
        rowMenu.classList.add("hidden");
      }
      if (!columnMenu.classList.contains("hidden") && !columnMenu.contains(ev.target)) {
        columnMenu.classList.add("hidden");
      }
      if (currentDropdown && currentDropdown.list && !currentDropdown.list.contains(ev.target)) {
        closeDropdown();
      }
    });

    document.addEventListener("mousemove", function (ev) {
      if (!dragging) return;
      var el = document.elementFromPoint(ev.clientX, ev.clientY);
      if (!el) return;
      var cell = el.closest ? el.closest(".data-cell") : null;
      if (!cell) return;
      var r1 = Number(cell.getAttribute("data-row"));
      var c1 = Number(cell.getAttribute("data-col"));
      updateSelection(dragWorkbook, dragWorksheet, dragging.startRow, dragging.startCol, r1, c1);
    });

    document.addEventListener("mouseup", function () {
      if (dragging) {
        dragging = null;
        if (dragWorkbook) {
          saveWorkbook(dragWorkbook);
        }
        dragWorkbook = null;
        dragWorksheet = null;
      }
    });

    exportBtn.addEventListener("click", function () {
      if (!currentWorkbook) return;
      var ws = currentWorkbook.worksheets.find(function (w) {
        return w.active;
      }) || currentWorkbook.worksheets[0];
      if (!ws) return;
      var rows = ws.rows || 0;
      var cols = ws.cols || 0;
      var lines = [];
      for (var r = 0; r < rows; r++) {
        var line = [];
        for (var c = 0; c < cols; c++) {
          var coord = colName(c) + (r + 1);
          var val = cellDisplayValue(ws, coord);
          line.push(escapeCSV(val));
        }
        lines.push(line.join(","));
      }
      var csv = lines.join("\r\n");
      var blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = (currentWorkbook.name || "worksheet") + ".csv";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () {
        URL.revokeObjectURL(url);
      }, 1000);
    });

    addWsBtn.addEventListener("click", function () {
      if (!currentWorkbook) return;
      addWsError.textContent = "";
      var existing = {};
      currentWorkbook.worksheets.forEach(function (w) {
        existing[w.name] = true;
      });
      var n = 1;
      var newName = "Sheet" + n;
      while (existing[newName]) {
        n += 1;
        newName = "Sheet" + n;
      }
      var prevActive = currentWorkbook.worksheets.find(function (w) {
        return w.active;
      });
      var newWs = {
        name: newName,
        active: true,
        rows: 100,
        cols: 26,
        cells: {},
        selection: { start: "A1", end: "A1" },
      };
      currentWorkbook.worksheets.forEach(function (w) {
        w.active = false;
      });
      pushUndo();
      currentWorkbook.worksheets.push(newWs);
      currentWorkbook.lastUpdated = new Date().toISOString();
      renderTabs(currentWorkbook);
      renderGrid(currentWorkbook);
      restoreSelection(newWs);
      saveWorkbook(currentWorkbook).catch(function () {
        // roll back on failure
        currentWorkbook.worksheets = currentWorkbook.worksheets.filter(function (w) {
          return w.name !== newName;
        });
        currentWorkbook.worksheets.forEach(function (w) {
          w.active = w === prevActive;
        });
        currentWorkbook.lastUpdated = new Date().toISOString();
        renderTabs(currentWorkbook);
        renderGrid(currentWorkbook);
        addWsError.textContent = "Could not add the worksheet.";
      });
    });

    function insertRow(rowIndex) {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var rows = ws.rows || 0;
      if (rowIndex < 0 || rowIndex > rows) {
        rowError.textContent = "Could not insert the row.";
        return;
      }
      var prevCells = JSON.parse(JSON.stringify(ws.cells || {}));
      var prevValidation = ws.validation ? JSON.parse(JSON.stringify(ws.validation)) : null;
      var prevRows = ws.rows;
      var prevSelection = ws.selection ? { start: ws.selection.start, end: ws.selection.end } : null;
      var prevFilters = ws.filters ? JSON.parse(JSON.stringify(ws.filters)) : null;
      var prevPivot = ws.pivot ? JSON.parse(JSON.stringify(ws.pivot)) : null;

      // Shift cells downward: rows >= rowIndex move down by one.
      var newCells = {};
      var cols = ws.cols || 0;
      for (var r = 0; r < rows; r++) {
        for (var c = 0; c < cols; c++) {
          var coord = formatCoord(r, c);
          var val = (ws.cells && ws.cells[coord]) || "";
          if (val === "") continue;
          if (r >= rowIndex) {
            newCells[formatCoord(r + 1, c)] = val;
          } else {
            newCells[coord] = val;
          }
        }
      }
      pushUndo();
      ws.cells = newCells;
      ws.rows = rows + 1;

      // Shift validation rule range downward if it overlaps the insertion point.
      if (ws.validation) {
        var v = ws.validation;
        var vRect = parseRangeRect(v.range);
        if (vRect) {
          if (vRect.top >= rowIndex) {
            v.range = formatCoord(vRect.top + 1, vRect.left) + ":" + formatCoord(vRect.bottom + 1, vRect.right);
          } else if (vRect.bottom >= rowIndex) {
            v.range = formatCoord(vRect.top, vRect.left) + ":" + formatCoord(vRect.bottom + 1, vRect.right);
          }
        }
      }

      // Adjust formula references in cells that shifted.
      adjustFormulasForRowShift(ws, rowIndex, 1);

      // Adjust selection.
      if (prevSelection) {
        var selRect = parseRect(prevSelection);
        if (selRect && selRect.top >= rowIndex) {
          ws.selection = {
            start: formatCoord(selRect.top + 1, selRect.left),
            end: formatCoord(selRect.bottom + 1, selRect.right),
          };
        }
      }

      currentWorkbook.lastUpdated = new Date().toISOString();
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      rowError.textContent = "";
      saveWorkbook(currentWorkbook)
        .then(function (r) {
          if (!r.ok) throw new Error("save failed");
        })
        .catch(function () {
          ws.cells = prevCells;
          ws.validation = prevValidation;
          ws.rows = prevRows;
          ws.selection = prevSelection;
          ws.filters = prevFilters;
          ws.pivot = prevPivot;
          currentWorkbook.lastUpdated = new Date().toISOString();
          renderGrid(currentWorkbook);
          restoreSelection(ws);
          rowError.textContent = "Could not insert the row.";
        });
    }

    function deleteRow(rowIndex) {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var rows = ws.rows || 0;
      if (rowIndex < 0 || rowIndex >= rows) {
        rowError.textContent = "Could not delete the row.";
        return;
      }
      var prevCells = JSON.parse(JSON.stringify(ws.cells || {}));
      var prevValidation = ws.validation ? JSON.parse(JSON.stringify(ws.validation)) : null;
      var prevRows = ws.rows;
      var prevSelection = ws.selection ? { start: ws.selection.start, end: ws.selection.end } : null;
      var prevFilters = ws.filters ? JSON.parse(JSON.stringify(ws.filters)) : null;
      var prevPivot = ws.pivot ? JSON.parse(JSON.stringify(ws.pivot)) : null;

      // Shift cells upward: rows > rowIndex move up by one; rowIndex removed.
      var newCells = {};
      var cols = ws.cols || 0;
      for (var r = 0; r < rows; r++) {
        if (r === rowIndex) continue;
        for (var c = 0; c < cols; c++) {
          var coord = formatCoord(r, c);
          var val = (ws.cells && ws.cells[coord]) || "";
          if (val === "") continue;
          if (r > rowIndex) {
            newCells[formatCoord(r - 1, c)] = val;
          } else {
            newCells[coord] = val;
          }
        }
      }
      pushUndo();
      ws.cells = newCells;
      ws.rows = rows - 1;

      // Remove or shift validation rule.
      if (ws.validation) {
        var v = ws.validation;
        var vRect = parseRangeRect(v.range);
        if (vRect) {
          if (vRect.top === rowIndex && vRect.bottom === rowIndex) {
            delete ws.validation;
          } else if (vRect.top <= rowIndex && vRect.bottom >= rowIndex) {
            v.range = formatCoord(vRect.top, vRect.left) + ":" + formatCoord(vRect.bottom - 1, vRect.right);
          } else if (vRect.top > rowIndex) {
            v.range = formatCoord(vRect.top - 1, vRect.left) + ":" + formatCoord(vRect.bottom - 1, vRect.right);
          }
        }
      }

      // Adjust formula references in cells that shifted.
      adjustFormulasForRowShift(ws, rowIndex, -1);

      // Adjust selection.
      if (prevSelection) {
        var selRect = parseRect(prevSelection);
        if (selRect) {
          if (selRect.top === rowIndex && selRect.bottom === rowIndex) {
            ws.selection = { start: formatCoord(Math.min(rowIndex, ws.rows - 1), selRect.left), end: formatCoord(Math.min(rowIndex, ws.rows - 1), selRect.right) };
          } else if (selRect.top > rowIndex) {
            ws.selection = {
              start: formatCoord(selRect.top - 1, selRect.left),
              end: formatCoord(selRect.bottom - 1, selRect.right),
            };
          } else if (selRect.bottom > rowIndex) {
            ws.selection = {
              start: formatCoord(selRect.top, selRect.left),
              end: formatCoord(selRect.bottom - 1, selRect.right),
            };
          }
        }
      }

      currentWorkbook.lastUpdated = new Date().toISOString();
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      rowError.textContent = "";
      saveWorkbook(currentWorkbook)
        .then(function (r) {
          if (!r.ok) throw new Error("save failed");
        })
        .catch(function () {
          ws.cells = prevCells;
          ws.validation = prevValidation;
          ws.rows = prevRows;
          ws.selection = prevSelection;
          ws.filters = prevFilters;
          ws.pivot = prevPivot;
          currentWorkbook.lastUpdated = new Date().toISOString();
          renderGrid(currentWorkbook);
          restoreSelection(ws);
          rowError.textContent = "Could not delete the row.";
        });
    }

    function adjustFormulasForRowShift(ws, rowIndex, delta) {
      var cells = ws.cells || {};
      var keys = Object.keys(cells);
      for (var i = 0; i < keys.length; i++) {
        var coord = keys[i];
        var val = cells[coord];
        if (!isFormula(val)) continue;
        var adjusted = adjustFormulaForRowShift(val, rowIndex, delta);
        if (adjusted === null) {
          cells[coord] = "#REF!";
        } else {
          cells[coord] = adjusted;
        }
      }
    }

    function adjustFormulaForRowShift(formula, rowIndex, delta) {
      var expr = formula.slice(1);
      var result = "=";
      var i = 0;
      var n = expr.length;
      var ok = true;
      while (i < n) {
        var ch = expr[i];
        if ((ch >= "A" && ch <= "Z") || (ch >= "a" && ch <= "z")) {
          var colAbs = false;
          var rowAbs = false;
          var colStr = "";
          var rowStr = "";
          if (expr[i] === "$") {
            colAbs = true;
            i++;
          }
          while (i < n && ((expr[i] >= "A" && expr[i] <= "Z") || (expr[i] >= "a" && expr[i] <= "z"))) {
            colStr += expr[i].toUpperCase();
            i++;
          }
          if (i < n && expr[i] === "$") {
            rowAbs = true;
            i++;
          }
          while (i < n && expr[i] >= "0" && expr[i] <= "9") {
            rowStr += expr[i];
            i++;
          }
          if (colStr && rowStr) {
            var col = colLettersToNumber(colStr) - 1;
            var row = Number(rowStr) - 1;
            if (!rowAbs) {
              if (delta < 0) {
                if (row === rowIndex) {
                  ok = false;
                } else if (row > rowIndex) {
                  row += delta;
                }
              } else {
                if (row >= rowIndex) {
                  row += delta;
                }
              }
            }
            if (ok) {
              result += (colAbs ? "$" : "") + colName(col) + (rowAbs ? "$" : "") + (row + 1);
            }
          } else {
            result += colStr + rowStr;
          }
        } else {
          result += ch;
          i++;
        }
      }
      return ok ? result : null;
    }

    function insertColumn(colIndex) {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var cols = ws.cols || 0;
      if (colIndex < 0 || colIndex > cols) {
        columnError.textContent = "Could not insert the column.";
        return;
      }
      var prevCells = JSON.parse(JSON.stringify(ws.cells || {}));
      var prevValidation = ws.validation ? JSON.parse(JSON.stringify(ws.validation)) : null;
      var prevCols = ws.cols;
      var prevSelection = ws.selection ? { start: ws.selection.start, end: ws.selection.end } : null;
      var prevFilters = ws.filters ? JSON.parse(JSON.stringify(ws.filters)) : null;
      var prevPivot = ws.pivot ? JSON.parse(JSON.stringify(ws.pivot)) : null;

      // Shift cells rightward: columns >= colIndex move right by one.
      var newCells = {};
      var rows = ws.rows || 0;
      for (var r = 0; r < rows; r++) {
        for (var c = 0; c < cols; c++) {
          var coord = formatCoord(r, c);
          var val = (ws.cells && ws.cells[coord]) || "";
          if (val === "") continue;
          if (c >= colIndex) {
            newCells[formatCoord(r, c + 1)] = val;
          } else {
            newCells[coord] = val;
          }
        }
      }
      pushUndo();
      ws.cells = newCells;
      ws.cols = cols + 1;

      // Shift validation rule range rightward if it overlaps the insertion point.
      if (ws.validation) {
        var v = ws.validation;
        var vRect = parseRangeRect(v.range);
        if (vRect) {
          if (vRect.left >= colIndex) {
            v.range = formatCoord(vRect.top, vRect.left + 1) + ":" + formatCoord(vRect.bottom, vRect.right + 1);
          } else if (vRect.right >= colIndex) {
            v.range = formatCoord(vRect.top, vRect.left) + ":" + formatCoord(vRect.bottom, vRect.right + 1);
          }
        }
      }

      // Adjust formula references in cells that shifted.
      adjustFormulasForColumnShift(ws, colIndex, 1);

      // Adjust filters: shift filter column indices >= colIndex right by one.
      if (ws.filters) {
        var newFilters = {};
        Object.keys(ws.filters).forEach(function (key) {
          var col = Number(key);
          if (col >= colIndex) {
            newFilters[String(col + 1)] = ws.filters[key];
          } else {
            newFilters[key] = ws.filters[key];
          }
        });
        ws.filters = newFilters;
      }

      // Adjust selection.
      if (prevSelection) {
        var selRect = parseRect(prevSelection);
        if (selRect && selRect.left >= colIndex) {
          ws.selection = {
            start: formatCoord(selRect.top, selRect.left + 1),
            end: formatCoord(selRect.bottom, selRect.right + 1),
          };
        }
      }

      currentWorkbook.lastUpdated = new Date().toISOString();
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      columnError.textContent = "";
      saveWorkbook(currentWorkbook)
        .then(function (r) {
          if (!r.ok) throw new Error("save failed");
        })
        .catch(function () {
          ws.cells = prevCells;
          ws.validation = prevValidation;
          ws.cols = prevCols;
          ws.selection = prevSelection;
          ws.filters = prevFilters;
          ws.pivot = prevPivot;
          currentWorkbook.lastUpdated = new Date().toISOString();
          renderGrid(currentWorkbook);
          restoreSelection(ws);
          columnError.textContent = "Could not insert the column.";
        });
    }

    function deleteColumn(colIndex) {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var cols = ws.cols || 0;
      if (colIndex < 0 || colIndex >= cols) {
        columnError.textContent = "Could not delete the column.";
        return;
      }
      var prevCells = JSON.parse(JSON.stringify(ws.cells || {}));
      var prevValidation = ws.validation ? JSON.parse(JSON.stringify(ws.validation)) : null;
      var prevCols = ws.cols;
      var prevSelection = ws.selection ? { start: ws.selection.start, end: ws.selection.end } : null;
      var prevFilters = ws.filters ? JSON.parse(JSON.stringify(ws.filters)) : null;
      var prevPivot = ws.pivot ? JSON.parse(JSON.stringify(ws.pivot)) : null;

      // Shift cells leftward: columns > colIndex move left by one; colIndex removed.
      var newCells = {};
      var rows = ws.rows || 0;
      for (var r = 0; r < rows; r++) {
        for (var c = 0; c < cols; c++) {
          if (c === colIndex) continue;
          var coord = formatCoord(r, c);
          var val = (ws.cells && ws.cells[coord]) || "";
          if (val === "") continue;
          if (c > colIndex) {
            newCells[formatCoord(r, c - 1)] = val;
          } else {
            newCells[coord] = val;
          }
        }
      }
      pushUndo();
      ws.cells = newCells;
      ws.cols = cols - 1;

      // Remove or shift validation rule.
      if (ws.validation) {
        var v = ws.validation;
        var vRect = parseRangeRect(v.range);
        if (vRect) {
          if (vRect.left === colIndex && vRect.right === colIndex) {
            delete ws.validation;
          } else if (vRect.left <= colIndex && vRect.right >= colIndex) {
            v.range = formatCoord(vRect.top, vRect.left) + ":" + formatCoord(vRect.bottom, vRect.right - 1);
          } else if (vRect.left > colIndex) {
            v.range = formatCoord(vRect.top, vRect.left - 1) + ":" + formatCoord(vRect.bottom, vRect.right - 1);
          }
        }
      }

      // Adjust formula references in cells that shifted.
      adjustFormulasForColumnShift(ws, colIndex, -1);

      // Adjust filters: remove filter on deleted column, shift others left.
      if (ws.filters) {
        var newFilters = {};
        Object.keys(ws.filters).forEach(function (key) {
          var col = Number(key);
          if (col === colIndex) return; // remove filter on deleted column
          if (col > colIndex) {
            newFilters[String(col - 1)] = ws.filters[key];
          } else {
            newFilters[key] = ws.filters[key];
          }
        });
        ws.filters = newFilters;
      }

      // Adjust selection.
      if (prevSelection) {
        var selRect = parseRect(prevSelection);
        if (selRect) {
          if (selRect.left === colIndex && selRect.right === colIndex) {
            ws.selection = { start: formatCoord(selRect.top, Math.min(colIndex, ws.cols - 1)), end: formatCoord(selRect.bottom, Math.min(colIndex, ws.cols - 1)) };
          } else if (selRect.left > colIndex) {
            ws.selection = {
              start: formatCoord(selRect.top, selRect.left - 1),
              end: formatCoord(selRect.bottom, selRect.right - 1),
            };
          } else if (selRect.right > colIndex) {
            ws.selection = {
              start: formatCoord(selRect.top, selRect.left),
              end: formatCoord(selRect.bottom, selRect.right - 1),
            };
          }
        }
      }

      currentWorkbook.lastUpdated = new Date().toISOString();
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      columnError.textContent = "";
      saveWorkbook(currentWorkbook)
        .then(function (r) {
          if (!r.ok) throw new Error("save failed");
        })
        .catch(function () {
          ws.cells = prevCells;
          ws.validation = prevValidation;
          ws.cols = prevCols;
          ws.selection = prevSelection;
          ws.filters = prevFilters;
          ws.pivot = prevPivot;
          currentWorkbook.lastUpdated = new Date().toISOString();
          renderGrid(currentWorkbook);
          restoreSelection(ws);
          columnError.textContent = "Could not delete the column.";
        });
    }

    function adjustFormulasForColumnShift(ws, colIndex, delta) {
      var cells = ws.cells || {};
      var keys = Object.keys(cells);
      for (var i = 0; i < keys.length; i++) {
        var coord = keys[i];
        var val = cells[coord];
        if (!isFormula(val)) continue;
        var adjusted = adjustFormulaForColumnShift(val, colIndex, delta);
        if (adjusted === null) {
          cells[coord] = "#REF!";
        } else {
          cells[coord] = adjusted;
        }
      }
    }

    function adjustFormulaForColumnShift(formula, colIndex, delta) {
      var expr = formula.slice(1);
      var result = "=";
      var i = 0;
      var n = expr.length;
      var ok = true;
      while (i < n) {
        var ch = expr[i];
        if ((ch >= "A" && ch <= "Z") || (ch >= "a" && ch <= "z")) {
          var colAbs = false;
          var rowAbs = false;
          var colStr = "";
          var rowStr = "";
          if (expr[i] === "$") {
            colAbs = true;
            i++;
          }
          while (i < n && ((expr[i] >= "A" && expr[i] <= "Z") || (expr[i] >= "a" && expr[i] <= "z"))) {
            colStr += expr[i].toUpperCase();
            i++;
          }
          if (i < n && expr[i] === "$") {
            rowAbs = true;
            i++;
          }
          while (i < n && expr[i] >= "0" && expr[i] <= "9") {
            rowStr += expr[i];
            i++;
          }
          if (colStr && rowStr) {
            var col = colLettersToNumber(colStr) - 1;
            var row = Number(rowStr) - 1;
            if (!colAbs) {
              if (delta < 0) {
                if (col === colIndex) {
                  ok = false;
                } else if (col > colIndex) {
                  col += delta;
                }
              } else {
                if (col >= colIndex) {
                  col += delta;
                }
              }
            }
            if (ok) {
              result += (colAbs ? "$" : "") + colName(col) + (rowAbs ? "$" : "") + (row + 1);
            }
          } else {
            result += colStr + rowStr;
          }
        } else {
          result += ch;
          i++;
        }
      }
      return ok ? result : null;
    }

    function parseRangeRect(range) {
      var m = String(range).match(/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/);
      if (!m) return null;
      var a = parseCoord(m[1] + m[2]);
      var b = parseCoord(m[3] + m[4]);
      if (!a || !b) return null;
      return {
        top: Math.min(a.row, b.row),
        bottom: Math.max(a.row, b.row),
        left: Math.min(a.col, b.col),
        right: Math.max(a.col, b.col),
      };
    }

    function renderTabs(wb) {
      tabsEl.innerHTML = "";
      wb.worksheets.forEach(function (ws) {
        var tab = document.createElement("button");
        tab.setAttribute("role", "tab");
        tab.setAttribute("aria-selected", ws.active ? "true" : "false");
        tab.textContent = ws.name;
        if (ws.active) tab.classList.add("active");
        tab.addEventListener("click", function (ev) {
          ev.stopPropagation();
          switchWorksheet(wb, ws);
          activeWs = ws;
        });
        tab.addEventListener("contextmenu", function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          showWorksheetMenu(tab, ws);
        });
        tabsEl.appendChild(tab);
      });
    }

    function showWorksheetMenu(tab, ws) {
      activeWs = ws;
      var rect = tab.getBoundingClientRect();
      worksheetMenu.style.left = rect.left + "px";
      worksheetMenu.style.top = rect.bottom + "px";
      worksheetMenu.classList.remove("hidden");
    }

    function switchWorksheet(wb, ws) {
      if (!ws) return;
      if (ws.active) {
        // Already active; just ensure a valid selection is shown.
        ensureSelection(ws);
        return;
      }
      wb.worksheets.forEach(function (w) {
        w.active = w === ws;
      });
      wb.lastUpdated = new Date().toISOString();
      // Close per-worksheet dialogs so they do not show stale state.
      filterDialog.classList.add("hidden");
      validationDialog.classList.add("hidden");
      createPivotDialog.classList.add("hidden");
      deleteWsDialog.classList.add("hidden");
      deleteWsError.textContent = "";
      renderTabs(wb);
      renderGrid(wb);
      // Update the formula bar to reflect the selected cell of the target
      // worksheet (ordinary value or original formula).
      var selRect = parseRect(ws.selection);
      var coord = selRect ? formatCoord(selRect.top, selRect.left) : "A1";
      currentCell = coord;
      committedValue = (ws.cells && ws.cells[coord]) || "";
      editing = false;
      formulaEl.value = committedValue;
      // Update the filter toolbar to the target worksheet's filters.
      filterRegion = detectRegion(ws);
      if (filterRegion && ws.filters && Object.keys(ws.filters).length > 0) {
        renderFilterToolbar(ws);
        filterToolbar.classList.remove("hidden");
      } else {
        filterToolbar.classList.add("hidden");
        filterHeaderButtons.innerHTML = "";
      }
      // Show/hide the pivot editor and result toolbar based on the worksheet.
      if (ws.pivot) {
        populatePivotEditor(ws);
        pivotEditor.classList.remove("hidden");
        pivotResultToolbar.classList.remove("hidden");
        pivotResultError.textContent = "";
      } else {
        pivotEditor.classList.add("hidden");
        pivotResultToolbar.classList.add("hidden");
        pivotResultError.textContent = "";
      }
      ensureSelection(ws);
      saveWorkbook(wb);
    }

    function ensureSelection(ws) {
      if (!ws) return;
      var selRect = parseRect(ws.selection);
      var coord = selRect ? formatCoord(selRect.top, selRect.left) : "A1";
      var el = gridEl.querySelector('[data-coord="' + coord + '"]');
      if (el) {
        el.focus();
      } else {
        selectA1();
      }
    }

    function restoreSelection(ws) {
      if (!ws) return;
      var selRect = parseRect(ws.selection);
      var coord = selRect ? formatCoord(selRect.top, selRect.left) : "A1";
      currentCell = coord;
      committedValue = (ws.cells && ws.cells[coord]) || "";
      editing = false;
      formulaEl.value = committedValue;
      var el = gridEl.querySelector('[data-coord="' + coord + '"]');
      if (el) {
        el.focus();
      } else {
        selectA1();
      }
    }

    function renderGrid(wb) {
      var ws = wb.worksheets.find(function (w) {
        return w.active;
      }) || wb.worksheets[0];
      if (!ws) return;
      gridEl.innerHTML = "";
      var rows = ws.rows || 0;
      var cols = ws.cols || 0;

      var headerRow = document.createElement("div");
      headerRow.className = "grid-row header-row";
      var corner = document.createElement("div");
      corner.className = "grid-cell corner";
      headerRow.appendChild(corner);
      for (var c = 0; c < cols; c++) {
        var h = document.createElement("div");
        h.className = "grid-cell col-header";
        h.setAttribute("role", "columnheader");
        h.setAttribute("data-col", String(c));
        h.textContent = colName(c);
        headerRow.appendChild(h);
      }
      gridEl.appendChild(headerRow);

      var selRect = parseRect(ws.selection);

      for (var r = 0; r < rows; r++) {
        if (rowIsFilteredOut(ws, r)) continue;
        var row = document.createElement("div");
        row.className = "grid-row";
        var rh = document.createElement("div");
        rh.className = "grid-cell row-header";
        rh.setAttribute("role", "rowheader");
        rh.setAttribute("data-row", String(r));
        rh.textContent = String(r + 1);
        row.appendChild(rh);
        for (var cc = 0; cc < cols; cc++) {
          var coord = colName(cc) + (r + 1);
          var cell = document.createElement("div");
          cell.className = "grid-cell data-cell";
          cell.setAttribute("role", "gridcell");
          cell.setAttribute("aria-label", coord);
          cell.setAttribute("data-coord", coord);
          cell.setAttribute("data-row", String(r));
          cell.setAttribute("data-col", String(cc));
          cell.setAttribute("contenteditable", "true");
          var inSel = selRect && r >= selRect.top && r <= selRect.bottom && cc >= selRect.left && cc <= selRect.right;
          cell.setAttribute("aria-selected", inSel ? "true" : "false");
          if (inSel) cell.classList.add("selected");
          cell.textContent = cellDisplayValue(ws, coord);
          var hasDropdown = ws.validation && ws.validation.type === "dropdown" && coordInRange(coord, ws.validation.range);
          if (hasDropdown) {
            cell.classList.add("has-dropdown");
            var dbtn = document.createElement("button");
            dbtn.type = "button";
            dbtn.className = "dropdown-btn";
            dbtn.setAttribute("aria-label", "Open dropdown for " + coord);
            dbtn.textContent = "▾";
            dbtn.setAttribute("contenteditable", "false");
            dbtn.addEventListener("mousedown", function (ev) {
              ev.preventDefault();
              ev.stopPropagation();
            });
            dbtn.addEventListener("click", function (ev) {
              ev.stopPropagation();
              openDropdown(ws, coord, dbtn);
            });
            cell.appendChild(dbtn);
          }
          cell.addEventListener("focus", function (ev) {
            var el = ev.currentTarget;
            var coord2 = el.getAttribute("data-coord");
            currentCell = coord2;
            currentCellEl = el;
            committedValue = (ws.cells && ws.cells[coord2]) || "";
            editing = false;
            formulaEl.value = committedValue;
          });
          cell.addEventListener("input", function (ev) {
            var el = ev.currentTarget;
            var coord2 = el.getAttribute("data-coord");
            var raw = "";
            for (var j = 0; j < el.childNodes.length; j++) {
              if (el.childNodes[j].nodeType === 3) {
                raw += el.childNodes[j].nodeValue;
              }
            }
            editing = true;
            formulaEl.value = raw;
          });
          cell.addEventListener("keydown", function (ev) {
            if (ev.key === "Enter") {
              ev.preventDefault();
              commitCell();
            } else if (ev.key === "Escape") {
              ev.preventDefault();
              cancelCell();
            } else if (
              !editing &&
              ev.key.length === 1 &&
              !ev.ctrlKey &&
              !ev.metaKey &&
              !ev.altKey
            ) {
              // Starting a fresh edit: replace the existing cell content.
              editing = true;
              var cellEl = ev.currentTarget;
              var btn = cellEl.querySelector(".dropdown-btn");
              if (btn) {
                var textNodes = [];
                for (var j = 0; j < cellEl.childNodes.length; j++) {
                  if (cellEl.childNodes[j].nodeType === 3) textNodes.push(cellEl.childNodes[j]);
                }
                for (var k = 0; k < textNodes.length; k++) {
                  cellEl.removeChild(textNodes[k]);
                }
              } else {
                cellEl.textContent = "";
              }
              formulaEl.value = "";
            }
          });
          cell.addEventListener("mousedown", function (ev) {
            ev.preventDefault();
            var el = ev.currentTarget;
            var coord2 = el.getAttribute("data-coord");
            if (editing && currentCell) {
              commitCell();
            }
            el.focus();
            var r0 = Number(el.getAttribute("data-row"));
            var c0 = Number(el.getAttribute("data-col"));
            startSelection(wb, ws, r0, c0);
            dragging = { startRow: r0, startCol: c0 };
            dragWorkbook = wb;
            dragWorksheet = ws;
          });
          row.appendChild(cell);
        }
        gridEl.appendChild(row);
      }
    }

    function activeWorksheet() {
      if (!currentWorkbook) return null;
      return currentWorkbook.worksheets.find(function (w) {
        return w.active;
      }) || currentWorkbook.worksheets[0];
    }

    function refreshAllCellDisplays(ws) {
      var cells = gridEl.querySelectorAll(".data-cell");
      for (var i = 0; i < cells.length; i++) {
        var cell = cells[i];
        var coord = cell.getAttribute("data-coord");
        if (coord) {
          var btn = cell.querySelector(".dropdown-btn");
          var display = cellDisplayValue(ws, coord);
          if (btn) {
            // preserve the dropdown button; replace only the text node
            var textNode = null;
            for (var j = 0; j < cell.childNodes.length; j++) {
              if (cell.childNodes[j].nodeType === 3) {
                textNode = cell.childNodes[j];
                break;
              }
            }
            if (textNode) {
              textNode.nodeValue = display;
            } else {
              cell.insertBefore(document.createTextNode(display), btn);
            }
          } else {
            cell.textContent = display;
          }
        }
      }
    }

    function commitCell() {
      if (!currentCell || !currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var raw = formulaEl.value;
      var prevValue = committedValue;
      var vErr = validateCellValue(ws, currentCell, raw);
      if (vErr) {
        if (cellError) cellError.textContent = vErr;
        refreshAllCellDisplays(ws);
        formulaEl.value = prevValue;
        editing = false;
        return;
      }
      if (!ws.cells) ws.cells = {};
      pushUndo();
      ws.cells[currentCell] = raw;
      editing = false;
      currentWorkbook.lastUpdated = new Date().toISOString();
      saveWorkbook(currentWorkbook)
        .then(function (r) {
          if (!r.ok) throw new Error("save failed");
          committedValue = raw;
          if (cellError) cellError.textContent = "";
          refreshAllCellDisplays(ws);
        })
        .catch(function () {
          ws.cells[currentCell] = prevValue;
          if (cellError) cellError.textContent = "Could not save the cell value.";
          refreshAllCellDisplays(ws);
          formulaEl.value = prevValue;
        });
    }

    function validateCellValue(ws, coord, value) {
      var validation = ws.validation;
      if (!validation) return null;
      if (!coordInRange(coord, validation.range)) return null;
      if (value === "" || value === undefined || value === null) return null;
      if (validation.type === "dropdown") {
        var allowed = validation.values || [];
        if (allowed.indexOf(String(value)) < 0) {
          return "Please select one of the following values: " + allowed.join(", ");
        }
      } else if (validation.type === "number-range") {
        var num = Number(value);
        if (isNaN(num)) return null;
        if (num < validation.min || num > validation.max) {
          var count = rangeCellCount(validation.range);
          if (count <= 2) {
            return "Please enter a number between " + validation.min + " and " + validation.max;
          }
          return "Please enter a number from " + validation.min + " to " + validation.max;
        }
      }
      return null;
    }

    function cancelCell() {
      if (!currentCell || !currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      editing = false;
      if (cellError) cellError.textContent = "";
      refreshAllCellDisplays(ws);
      formulaEl.value = committedValue;
    }

    function openDropdown(ws, coord, btn) {
      closeDropdown();
      var validation = ws.validation;
      if (!validation || validation.type !== "dropdown") return;
      var list = document.createElement("div");
      list.className = "dropdown-list";
      list.setAttribute("role", "listbox");
      list.setAttribute("aria-label", "Options for " + coord);
      var rect = btn.getBoundingClientRect();
      list.style.left = rect.left + "px";
      list.style.top = rect.bottom + 2 + "px";
      (validation.values || []).forEach(function (val) {
        var opt = document.createElement("div");
        opt.setAttribute("role", "option");
        opt.textContent = val;
        opt.addEventListener("click", function () {
          setCellValueFromDropdown(ws, coord, val);
          closeDropdown();
        });
        list.appendChild(opt);
      });
      document.body.appendChild(list);
      currentDropdown = { list: list, coord: coord };
    }

    function closeDropdown() {
      if (currentDropdown && currentDropdown.list && currentDropdown.list.parentNode) {
        currentDropdown.list.parentNode.removeChild(currentDropdown.list);
      }
      currentDropdown = null;
    }

    function setCellValueFromDropdown(ws, coord, val) {
      if (!ws.cells) ws.cells = {};
      var prevValue = (ws.cells[coord] !== undefined ? ws.cells[coord] : "");
      pushUndo();
      ws.cells[coord] = val;
      currentWorkbook.lastUpdated = new Date().toISOString();
      saveWorkbook(currentWorkbook)
        .then(function (r) {
          if (!r.ok) throw new Error("save failed");
          if (cellError) cellError.textContent = "";
          refreshAllCellDisplays(ws);
          if (currentCell === coord) {
            committedValue = val;
            formulaEl.value = val;
          }
        })
        .catch(function () {
          ws.cells[coord] = prevValue;
          if (cellError) cellError.textContent = "Could not save the cell value.";
          refreshAllCellDisplays(ws);
        });
    }

    function pasteFromClipboard() {
      if (!currentWorkbook || !currentCell) return;
      if (navigator.clipboard && navigator.clipboard.readText) {
        navigator.clipboard
          .readText()
          .then(function (text) {
            if (text) applyPaste(text);
          })
          .catch(function () {
            if (cellError) cellError.textContent = "Could not read the clipboard.";
          });
      } else {
        if (cellError) cellError.textContent = "Clipboard access is not available.";
      }
    }

    function copySelection(mode) {
      if (!currentWorkbook) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var rect = parseRect(ws.selection);
      if (!rect) return;
      var cells = {};
      for (var r = rect.top; r <= rect.bottom; r++) {
        for (var c = rect.left; c <= rect.right; c++) {
          var coord = formatCoord(r, c);
          cells[coord] = (ws.cells && ws.cells[coord]) || "";
        }
      }
      clipboard = {
        mode: mode,
        worksheet: ws.name,
        cells: cells,
        startRow: rect.top,
        startCol: rect.left,
        numRows: rect.bottom - rect.top + 1,
        numCols: rect.right - rect.left + 1,
      };
      if (cellError) cellError.textContent = "";
    }

    function pasteFromInternalClipboard() {
      if (!clipboard || !currentWorkbook || !currentCell) return;
      var ws = activeWorksheet();
      if (!ws) return;
      if (clipboard.worksheet !== ws.name) {
        if (cellError) cellError.textContent = "Copy and paste must be within the same worksheet.";
        return;
      }
      var start = parseCoord(currentCell);
      if (!start) return;
      var numRows = clipboard.numRows;
      var numCols = clipboard.numCols;
      if (start.row + numRows > (ws.rows || 0) || start.col + numCols > (ws.cols || 0)) {
        if (cellError) cellError.textContent = "Paste would extend beyond the worksheet.";
        return;
      }
      var dr = start.row - clipboard.startRow;
      var dc = start.col - clipboard.startCol;

      var newCells = {};
      Object.keys(clipboard.cells).forEach(function (coord) {
        var src = parseCoord(coord);
        var newCoord = formatCoord(src.row + dr, src.col + dc);
        var val = clipboard.cells[coord];
        if (isFormula(val)) {
          val = adjustFormula(val, dr, dc);
        }
        newCells[newCoord] = val;
      });

      var validationError = validatePasteCells(ws, newCells);
      if (validationError) {
        if (cellError) cellError.textContent = validationError;
        return;
      }

      var changes = {};
      Object.keys(newCells).forEach(function (coord) {
        changes[coord] = newCells[coord];
      });
      if (clipboard.mode === "cut") {
        Object.keys(clipboard.cells).forEach(function (coord) {
          if (!(coord in newCells)) {
            changes[coord] = "";
          }
        });
      }

      var originals = {};
      Object.keys(changes).forEach(function (coord) {
        originals[coord] = (ws.cells && ws.cells[coord]) || "";
      });

      if (!ws.cells) ws.cells = {};
      pushUndo();
      Object.keys(changes).forEach(function (coord) {
        ws.cells[coord] = changes[coord];
      });
      currentWorkbook.lastUpdated = new Date().toISOString();

      saveWorkbook(currentWorkbook)
        .then(function (r) {
          if (!r.ok) throw new Error("save failed");
          if (cellError) cellError.textContent = "";
          refreshAllCellDisplays(ws);
          if (currentCell) {
            committedValue = (ws.cells && ws.cells[currentCell]) || "";
            formulaEl.value = committedValue;
          }
          if (clipboard.mode === "cut") {
            clipboard = null;
          }
        })
        .catch(function () {
          Object.keys(changes).forEach(function (coord) {
            ws.cells[coord] = originals[coord];
          });
          if (cellError) cellError.textContent = "Could not save the pasted values.";
          refreshAllCellDisplays(ws);
        });
    }

    function validatePasteCells(ws, cells) {
      var validation = ws.validation;
      if (!validation) return null;
      var keys = Object.keys(cells);
      for (var i = 0; i < keys.length; i++) {
        var coord = keys[i];
        var val = cells[coord];
        var vErr = validatePasteCellValue(ws, coord, val);
        if (vErr) return vErr;
      }
      return null;
    }

    function validatePasteCellValue(ws, coord, value) {
      var validation = ws.validation;
      if (!validation) return null;
      if (!coordInRange(coord, validation.range)) return null;
      if (value === "" || value === undefined || value === null) return null;
      if (validation.type === "dropdown") {
        var allowed = validation.values || [];
        if (allowed.indexOf(String(value)) < 0) {
          return "Please select one of the following values: " + allowed.join(", ");
        }
      } else if (validation.type === "number-range") {
        var num = Number(value);
        if (isNaN(num)) return null;
        if (num < validation.min || num > validation.max) {
          return "Please enter a number from " + validation.min + " to " + validation.max;
        }
      }
      return null;
    }

    function applyPaste(text) {
      if (!currentWorkbook || !currentCell) return;
      var ws = activeWorksheet();
      if (!ws) return;
      var start = parseCoord(currentCell);
      if (!start) return;

      var lines = String(text).split(/\r?\n/);
      if (lines.length > 0 && lines[lines.length - 1] === "") {
        lines.pop();
      }
      if (lines.length === 0) return;
      var rows = lines.map(function (line) {
        return line.split("\t");
      });
      var numRows = rows.length;
      var numCols = rows.reduce(function (m, r) {
        return Math.max(m, r.length);
      }, 0);
      if (numRows === 0 || numCols === 0) return;

      if (start.row + numRows > (ws.rows || 0) || start.col + numCols > (ws.cols || 0)) {
        if (cellError) cellError.textContent = "Paste would extend beyond the worksheet.";
        return;
      }

      var validationError = validatePaste(ws, start, rows, numRows, numCols);
      if (validationError) {
        if (cellError) cellError.textContent = validationError;
        return;
      }

      var newCells = {};
      for (var r = 0; r < numRows; r++) {
        for (var c = 0; c < numCols; c++) {
          var coord = colName(start.col + c) + (start.row + r + 1);
          var val = rows[r][c] !== undefined ? rows[r][c] : "";
          newCells[coord] = val;
        }
      }

      var originalCells = {};
      Object.keys(newCells).forEach(function (coord) {
        originalCells[coord] = (ws.cells && ws.cells[coord]) || "";
      });

      if (!ws.cells) ws.cells = {};
      pushUndo();
      Object.keys(newCells).forEach(function (coord) {
        ws.cells[coord] = newCells[coord];
      });
      currentWorkbook.lastUpdated = new Date().toISOString();

      saveWorkbook(currentWorkbook)
        .then(function (r) {
          if (!r.ok) throw new Error("save failed");
          if (cellError) cellError.textContent = "";
          refreshAllCellDisplays(ws);
          if (currentCell) {
            committedValue = (ws.cells && ws.cells[currentCell]) || "";
            formulaEl.value = committedValue;
          }
        })
        .catch(function () {
          Object.keys(newCells).forEach(function (coord) {
            ws.cells[coord] = originalCells[coord];
          });
          if (cellError) cellError.textContent = "Could not save the pasted values.";
          refreshAllCellDisplays(ws);
        });
    }

    function validatePaste(ws, start, rows, numRows, numCols) {
      var validation = ws.validation;
      if (!validation) return null;
      for (var r = 0; r < numRows; r++) {
        for (var c = 0; c < numCols; c++) {
          var coord = colName(start.col + c) + (start.row + r + 1);
          var val = rows[r][c] !== undefined ? rows[r][c] : "";
          var vErr = validatePasteCellValue(ws, coord, val);
          if (vErr) return vErr;
        }
      }
      return null;
    }

    function coordInRange(coord, range) {
      var m = String(range).match(/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/);
      if (!m) return false;
      var a = parseCoord(m[1] + m[2]);
      var b = parseCoord(m[3] + m[4]);
      var p = parseCoord(coord);
      if (!a || !b || !p) return false;
      return (
        p.row >= Math.min(a.row, b.row) &&
        p.row <= Math.max(a.row, b.row) &&
        p.col >= Math.min(a.col, b.col) &&
        p.col <= Math.max(a.col, b.col)
      );
    }

    function rangeCellCount(range) {
      var m = String(range).match(/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/);
      if (!m) return 0;
      var a = parseCoord(m[1] + m[2]);
      var b = parseCoord(m[3] + m[4]);
      if (!a || !b) return 0;
      return (Math.abs(a.row - b.row) + 1) * (Math.abs(a.col - b.col) + 1);
    }

    function detectRegion(ws) {
      var cells = ws.cells || {};
      var headers = [];
      var c = 0;
      while (c < (ws.cols || 0)) {
        var coord = colName(c) + "1";
        var val = cells[coord];
        if (val === undefined || val === "") break;
        headers.push({ col: c, name: String(val) });
        c++;
      }
      if (headers.length === 0) return null;
      var dataRows = [];
      var r = 1;
      while (r < (ws.rows || 0)) {
        var hasData = false;
        for (var i = 0; i < headers.length; i++) {
          var coord2 = colName(headers[i].col) + (r + 1);
          var v = cells[coord2];
          if (v !== undefined && v !== "") {
            hasData = true;
            break;
          }
        }
        if (!hasData) break;
        dataRows.push(r);
        r++;
      }
      return { headers: headers, dataRows: dataRows };
    }

    function renderFilterToolbar(ws) {
      filterHeaderButtons.innerHTML = "";
      if (!filterRegion) return;
      filterRegion.headers.forEach(function (h) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.textContent = "Filter " + h.name;
        btn.setAttribute("aria-label", "Filter " + h.name);
        btn.addEventListener("click", function () {
          openFilterDialog(ws, h.col);
        });
        filterHeaderButtons.appendChild(btn);
      });
    }

    function openFilterDialog(ws, colIndex) {
      filterColumn = colIndex;
      var header = null;
      if (filterRegion) {
        filterRegion.headers.forEach(function (h) {
          if (h.col === colIndex) header = h;
        });
      }
      var headerName = header ? header.name : colName(colIndex);
      filterDialogTitle.textContent = "Filter " + headerName;
      filterDialog.setAttribute("aria-label", "Filter " + headerName);
      filterError.textContent = "";

      // Build distinct value checkboxes
      filterValues.innerHTML = "";
      var seen = {};
      var distinct = [];
      var cells = ws.cells || {};
      for (var i = 0; i < filterRegion.dataRows.length; i++) {
        var r = filterRegion.dataRows[i];
        var coord = colName(colIndex) + (r + 1);
        var v = cells[coord];
        if (v === undefined) v = "";
        v = String(v);
        if (!seen[v]) {
          seen[v] = true;
          distinct.push(v);
        }
      }
      var currentFilter = (ws.filters && ws.filters[colIndex]) || {};
      var hasValues = currentFilter.hasOwnProperty("values");
      var currentValues = hasValues ? (currentFilter.values || []) : null;
      distinct.forEach(function (val) {
        var label = document.createElement("label");
        label.className = "filter-checkbox";
        var box = document.createElement("input");
        box.type = "checkbox";
        box.value = val;
        box.checked = hasValues ? currentValues.indexOf(val) >= 0 : true;
        label.appendChild(box);
        label.appendChild(document.createTextNode(val));
        filterValues.appendChild(label);
      });

      // Pre-fill condition
      if (currentFilter.condition) {
        filterCondition.value = currentFilter.condition.type;
        filterValueInput.value = currentFilter.condition.value || "";
      } else {
        filterCondition.value = "Text contains";
        filterValueInput.value = "";
      }
      filterDialog.classList.remove("hidden");
    }

    function rowIsFilteredOut(ws, rowIndex) {
      // The header row (row 0) is always visible; only data rows are filtered.
      if (rowIndex === 0) return false;
      var filters = ws.filters;
      if (!filters) return false;
      var cells = ws.cells || {};
      var keys = Object.keys(filters);
      for (var i = 0; i < keys.length; i++) {
        var col = Number(keys[i]);
        var f = filters[keys[i]];
        if (!f) continue;
        var coord = colName(col) + (rowIndex + 1);
        var cellVal = cells[coord];
        if (cellVal === undefined) cellVal = "";
        cellVal = String(cellVal);
        if (f.hasOwnProperty("values")) {
          if (f.values.indexOf(cellVal) < 0) return true;
        }
        if (f.condition) {
          if (!matchesCondition(cellVal, f.condition)) return true;
        }
      }
      return false;
    }

    function matchesCondition(cellVal, cond) {
      var type = cond.type;
      var value = cond.value;
      if (type === "Is empty") {
        return cellVal === "";
      }
      if (type === "Is not empty") {
        return cellVal !== "";
      }
      if (type === "Text contains") {
        return cellVal.toLowerCase().indexOf(String(value).toLowerCase()) >= 0;
      }
      if (type === "Greater than") {
        var n = Number(cellVal);
        var v = Number(value);
        if (isNaN(n) || isNaN(v)) return false;
        return n > v;
      }
      if (type === "Before") {
        var d = new Date(cellVal);
        var dv = new Date(value);
        if (isNaN(d.getTime()) || isNaN(dv.getTime())) return false;
        return d.getTime() < dv.getTime();
      }
      return true;
    }

    function startSelection(wb, ws, row, col) {
      ws.selection = { start: formatCoord(row, col), end: formatCoord(row, col) };
      applySelection(ws);
    }

    function updateSelection(wb, ws, startRow, startCol, endRow, endCol) {
      ws.selection = { start: formatCoord(startRow, startCol), end: formatCoord(endRow, endCol) };
      applySelection(ws);
    }

    function applySelection(ws) {
      var selRect = parseRect(ws.selection);
      var cells = gridEl.querySelectorAll(".data-cell");
      for (var i = 0; i < cells.length; i++) {
        var cell = cells[i];
        var r = Number(cell.getAttribute("data-row"));
        var c = Number(cell.getAttribute("data-col"));
        var inSel = selRect && r >= selRect.top && r <= selRect.bottom && c >= selRect.left && c <= selRect.right;
        cell.setAttribute("aria-selected", inSel ? "true" : "false");
        if (inSel) cell.classList.add("selected");
        else cell.classList.remove("selected");
      }
    }

    function selectA1() {
      var a1 = gridEl.querySelector('[data-coord="A1"]');
      if (a1) {
        a1.focus();
      }
    }

    function saveWorkbook(wb) {
      return fetch("/api/workbooks/" + encodeURIComponent(wb.id), {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ worksheets: wb.worksheets }),
      });
    }

    function pushUndo() {
      if (!currentWorkbook) return;
      undoStack.push(JSON.parse(JSON.stringify(currentWorkbook.worksheets)));
      if (undoStack.length > 200) undoStack.shift();
      redoStack = [];
      updateUndoRedoButtons();
    }

    function undo() {
      if (!currentWorkbook || undoStack.length === 0) return;
      redoStack.push(JSON.parse(JSON.stringify(currentWorkbook.worksheets)));
      var prev = undoStack.pop();
      currentWorkbook.worksheets = prev;
      currentWorkbook.lastUpdated = new Date().toISOString();
      refreshAfterUndoRedo();
      saveWorkbook(currentWorkbook);
      updateUndoRedoButtons();
    }

    function redo() {
      if (!currentWorkbook || redoStack.length === 0) return;
      undoStack.push(JSON.parse(JSON.stringify(currentWorkbook.worksheets)));
      var next = redoStack.pop();
      currentWorkbook.worksheets = next;
      currentWorkbook.lastUpdated = new Date().toISOString();
      refreshAfterUndoRedo();
      saveWorkbook(currentWorkbook);
      updateUndoRedoButtons();
    }

    function refreshAfterUndoRedo() {
      var ws = activeWorksheet();
      if (!ws) return;
      renderTabs(currentWorkbook);
      renderGrid(currentWorkbook);
      restoreSelection(ws);
      filterRegion = detectRegion(ws);
      if (filterRegion && ws.filters && Object.keys(ws.filters).length > 0) {
        renderFilterToolbar(ws);
        filterToolbar.classList.remove("hidden");
      } else {
        filterToolbar.classList.add("hidden");
        filterHeaderButtons.innerHTML = "";
      }
      if (ws.pivot) {
        populatePivotEditor(ws);
        pivotEditor.classList.remove("hidden");
        pivotResultToolbar.classList.remove("hidden");
        pivotResultError.textContent = "";
      } else {
        pivotEditor.classList.add("hidden");
        pivotResultToolbar.classList.add("hidden");
        pivotResultError.textContent = "";
      }
      filterDialog.classList.add("hidden");
      validationDialog.classList.add("hidden");
      createPivotDialog.classList.add("hidden");
      deleteWsDialog.classList.add("hidden");
      renameDialog.classList.add("hidden");
      renameWsDialog.classList.add("hidden");
      dataMenu.classList.add("hidden");
      gridMenu.classList.add("hidden");
      rowMenu.classList.add("hidden");
      columnMenu.classList.add("hidden");
      worksheetMenu.classList.add("hidden");
      closeDropdown();
      if (cellError) cellError.textContent = "";
      filterError.textContent = "";
      rowError.textContent = "";
      columnError.textContent = "";
      addWsError.textContent = "";
      pivotError.textContent = "";
      pivotResultError.textContent = "";
      validationError.textContent = "";
      renameError.textContent = "";
      renameWsError.textContent = "";
      deleteWsError.textContent = "";
    }

    function updateUndoRedoButtons() {
      var uBtn = document.getElementById("undo-btn");
      var rBtn = document.getElementById("redo-btn");
      if (uBtn) uBtn.disabled = undoStack.length === 0;
      if (rBtn) rBtn.disabled = redoStack.length === 0;
    }
  }

  function isFormula(value) {
    return typeof value === "string" && value.charAt(0) === "=";
  }

  function cellDisplayValue(ws, coord) {
    var val = (ws.cells && ws.cells[coord]) || "";
    if (isFormula(val)) {
      return evaluateFormula(val, ws);
    }
    return val;
  }

  function formulaError(code) {
    var e = new Error(code);
    e.code = code;
    return e;
  }

  function evaluateFormula(formula, ws, visited) {
    if (!visited) visited = {};
    var expr = formula.slice(1).trim();
    if (expr === "") return "";
    try {
      var tokens = tokenizeFormula(expr);
      var result = parseFormulaExpression(tokens, ws, visited);
      if (tokens.length > 0) throw formulaError("#ERROR!");
      return formatFormulaResult(result);
    } catch (e) {
      if (e && e.code) return e.code;
      return "#ERROR!";
    }
  }

  function tokenizeFormula(expr) {
    var tokens = [];
    var i = 0;
    var n = expr.length;
    while (i < n) {
      var ch = expr[i];
      if (ch === " " || ch === "\t") {
        i++;
        continue;
      }
      if ((ch >= "0" && ch <= "9") || ch === ".") {
        var num = "";
        while (i < n && ((expr[i] >= "0" && expr[i] <= "9") || expr[i] === ".")) {
          num += expr[i];
          i++;
        }
        tokens.push({ type: "num", value: Number(num) });
      } else if ((ch >= "A" && ch <= "Z") || (ch >= "a" && ch <= "z") || ch === "$") {
        var ident = "";
        var sawLetter = false;
        while (i < n) {
          var cc = expr[i];
          if ((cc >= "A" && cc <= "Z") || (cc >= "a" && cc <= "z")) {
            ident += cc;
            sawLetter = true;
            i++;
          } else if (cc >= "0" && cc <= "9") {
            ident += cc;
            i++;
          } else if (cc === "$") {
            var next = expr[i + 1];
            if (
              next !== undefined &&
              ((next >= "A" && next <= "Z") ||
                (next >= "a" && next <= "z") ||
                (next >= "0" && next <= "9"))
            ) {
              ident += "$";
              i++;
            } else {
              break;
            }
          } else {
            break;
          }
        }
        if (!sawLetter) throw new Error("Unknown character: " + ch);
        // Look ahead past whitespace to see if this is a function call.
        var j = i;
        while (j < n && (expr[j] === " " || expr[j] === "\t")) j++;
        if (j < n && expr[j] === "(") {
          tokens.push({ type: "func", value: ident.toUpperCase() });
        } else {
          tokens.push({ type: "ref", value: ident.toUpperCase() });
        }
      } else if ("+-*/()".indexOf(ch) >= 0) {
        tokens.push({ type: "op", value: ch });
        i++;
      } else if (ch === ":") {
        tokens.push({ type: "op", value: ":" });
        i++;
      } else {
        throw new Error("Unknown character: " + ch);
      }
    }
    return tokens;
  }

  function parseFormulaExpression(tokens, ws, visited) {
    var left = parseFormulaTerm(tokens, ws, visited);
    while (tokens.length > 0 && (tokens[0].value === "+" || tokens[0].value === "-")) {
      var op = tokens.shift().value;
      var right = parseFormulaTerm(tokens, ws, visited);
      left = toNumber(left) + (op === "+" ? toNumber(right) : -toNumber(right));
    }
    return left;
  }

  function parseFormulaTerm(tokens, ws, visited) {
    var left = parseFormulaFactor(tokens, ws, visited);
    while (tokens.length > 0 && (tokens[0].value === "*" || tokens[0].value === "/")) {
      var op = tokens.shift().value;
      var right = parseFormulaFactor(tokens, ws, visited);
      if (op === "*") {
        left = toNumber(left) * toNumber(right);
      } else {
        var rn = toNumber(right);
        if (rn === 0) throw formulaError("#DIV/0!");
        left = toNumber(left) / rn;
      }
    }
    return left;
  }

  function parseFormulaFactor(tokens, ws, visited) {
    var tok = tokens.shift();
    if (!tok) throw formulaError("#ERROR!");
    if (tok.type === "num") return tok.value;
    if (tok.type === "ref") {
      // A range like A1:B2
      if (tokens.length > 0 && tokens[0].type === "op" && tokens[0].value === ":") {
        tokens.shift();
        var endTok = tokens.shift();
        if (!endTok || endTok.type !== "ref") throw formulaError("#ERROR!");
        return { range: [tok.value, endTok.value] };
      }
      return resolveRef(tok.value, ws, visited);
    }
    if (tok.type === "func") {
      return parseFormulaFunction(tok.value, tokens, ws, visited);
    }
    if (tok.type === "op" && tok.value === "(") {
      var inner = parseFormulaExpression(tokens, ws, visited);
      var close = tokens.shift();
      if (!close || close.value !== ")") throw formulaError("#ERROR!");
      return inner;
    }
    if (tok.type === "op" && tok.value === "-") {
      return -toNumber(parseFormulaFactor(tokens, ws, visited));
    }
    throw formulaError("#ERROR!");
  }

  function resolveRef(coord, ws, visited) {
    var clean = String(coord).replace(/\$/g, "");
    if (visited[clean]) throw formulaError("#REF!");
    var cells = ws.cells || {};
    var pc = parseCoord(clean);
    if (!pc || pc.row < 0 || pc.col < 0 || pc.row >= (ws.rows || 0) || pc.col >= (ws.cols || 0)) {
      throw formulaError("#REF!");
    }
    var val = cells[clean];
    if (val === undefined || val === "") return 0;
    if (isFormula(val)) {
      visited[clean] = true;
      var r = evaluateFormula(val, ws, visited);
      delete visited[clean];
      return r;
    }
    var num = Number(val);
    if (isNaN(num)) return val;
    return num;
  }

  function parseFormulaFunction(name, tokens, ws, visited) {
    var open = tokens.shift();
    if (!open || open.value !== "(") throw formulaError("#ERROR!");
    var arg = parseFormulaFactor(tokens, ws, visited);
    var close = tokens.shift();
    if (!close || close.value !== ")") throw formulaError("#ERROR!");
    if (arg && arg.range) {
      return applyAggregate(name, arg.range[0], arg.range[1], ws, visited);
    }
    var isNum = typeof arg === "number" || (typeof arg === "string" && arg !== "" && !isNaN(Number(arg)));
    return aggregateNumbers(name, isNum ? [toNumber(arg)] : []);
  }

  function applyAggregate(name, start, end, ws, visited) {
    var coords = getRangeCells(start, end);
    var nums = [];
    for (var i = 0; i < coords.length; i++) {
      var n = cellNumericValue(coords[i], ws, visited);
      if (n !== null) nums.push(n);
    }
    return aggregateNumbers(name, nums);
  }

  function getRangeCells(start, end) {
    var sc = parseCoord(start);
    var ec = parseCoord(end);
    if (!sc || !ec) return [];
    var r0 = Math.min(sc.row, ec.row);
    var r1 = Math.max(sc.row, ec.row);
    var c0 = Math.min(sc.col, ec.col);
    var c1 = Math.max(sc.col, ec.col);
    var result = [];
    for (var r = r0; r <= r1; r++) {
      for (var c = c0; c <= c1; c++) {
        result.push(colName(c) + (r + 1));
      }
    }
    return result;
  }

  function cellNumericValue(coord, ws, visited) {
    var cells = ws.cells || {};
    var val = cells[coord];
    if (val === undefined || val === null || val === "") return null;
    if (isFormula(val)) {
      if (visited[coord]) throw formulaError("#REF!");
      visited[coord] = true;
      var r = evaluateFormula(val, ws, visited);
      delete visited[coord];
      var n = Number(r);
      return isNaN(n) ? null : n;
    }
    var n = Number(val);
    return isNaN(n) ? null : n;
  }

  function aggregateNumbers(name, nums) {
    if (name === "SUM") {
      var s = 0;
      for (var i = 0; i < nums.length; i++) s += nums[i];
      return s;
    }
    if (name === "COUNT") return nums.length;
    if (name === "AVERAGE") {
      if (nums.length === 0) return 0;
      var s2 = 0;
      for (var i = 0; i < nums.length; i++) s2 += nums[i];
      return s2 / nums.length;
    }
    if (name === "MIN") {
      if (nums.length === 0) return 0;
      var m = nums[0];
      for (var i = 1; i < nums.length; i++) if (nums[i] < m) m = nums[i];
      return m;
    }
    if (name === "MAX") {
      if (nums.length === 0) return 0;
      var m2 = nums[0];
      for (var i = 1; i < nums.length; i++) if (nums[i] > m2) m2 = nums[i];
      return m2;
    }
    throw formulaError("#NAME?");
  }

  function toNumber(v) {
    if (typeof v === "number") return v;
    var n = Number(v);
    return isNaN(n) ? 0 : n;
  }

  function formatFormulaResult(result) {
    if (typeof result === "number") {
      if (Number.isInteger(result)) return String(result);
      return String(Math.round(result * 1000000) / 1000000);
    }
    return String(result);
  }

  function escapeCSV(val) {
    var s = String(val);
    if (/[",\r\n]/.test(s)) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  }

  function colName(i) {
    var s = "";
    i = i + 1;
    while (i > 0) {
      var rem = (i - 1) % 26;
      s = String.fromCharCode(65 + rem) + s;
      i = Math.floor((i - 1) / 26);
    }
    return s;
  }

  function colLettersToNumber(letters) {
    var col = 0;
    for (var i = 0; i < letters.length; i++) {
      col = col * 26 + (letters.charCodeAt(i) - 64);
    }
    return col;
  }

  function adjustFormula(formula, dr, dc) {
    var expr = formula.slice(1);
    var result = "=";
    var i = 0;
    var n = expr.length;
    while (i < n) {
      var ch = expr[i];
      var isLetter = (ch >= "A" && ch <= "Z") || (ch >= "a" && ch <= "z");
      if (isLetter || ch === "$") {
        var colAbs = false;
        var rowAbs = false;
        var colStr = "";
        var rowStr = "";
        var j = i;
        if (expr[j] === "$") {
          colAbs = true;
          j++;
        }
        while (j < n && ((expr[j] >= "A" && expr[j] <= "Z") || (expr[j] >= "a" && expr[j] <= "z"))) {
          colStr += expr[j].toUpperCase();
          j++;
        }
        if (j < n && expr[j] === "$") {
          rowAbs = true;
          j++;
        }
        while (j < n && expr[j] >= "0" && expr[j] <= "9") {
          rowStr += expr[j];
          j++;
        }
        if (colStr && rowStr) {
          var col = colLettersToNumber(colStr) - 1;
          var row = Number(rowStr) - 1;
          if (!colAbs) col += dc;
          if (!rowAbs) row += dr;
          result += (colAbs ? "$" : "") + colName(col) + (rowAbs ? "$" : "") + (row + 1);
          i = j;
        } else {
          result += ch;
          i++;
        }
      } else {
        result += ch;
        i++;
      }
    }
    return result;
  }

  function parseCoord(coord) {
    var m = String(coord).replace(/\$/g, "").match(/^([A-Z]+)(\d+)$/);
    if (!m) return null;
    var col = 0;
    var letters = m[1];
    for (var i = 0; i < letters.length; i++) {
      col = col * 26 + (letters.charCodeAt(i) - 64);
    }
    return { row: Number(m[2]) - 1, col: col - 1 };
  }

  function formatCoord(row, col) {
    return colName(col) + (row + 1);
  }

  function parseRect(sel) {
    if (!sel || !sel.start || !sel.end) return null;
    var a = parseCoord(sel.start);
    var b = parseCoord(sel.end);
    if (!a || !b) return null;
    return {
      top: Math.min(a.row, b.row),
      bottom: Math.max(a.row, b.row),
      left: Math.min(a.col, b.col),
      right: Math.max(a.col, b.col),
    };
  }

  function formatDate(iso) {
    if (!iso) return "unknown";
    var d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString();
  }
})();
