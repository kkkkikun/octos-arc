import { expect, test } from '@playwright/test';
import * as h from './helpers';

// requirement: REQ-4.4.9
// fixtures: passenger_manager_user

test('REQ-4.4.9: Confirm batch deletion of selected passengers', async ({ page }) => {
  await h.openMyPassengers(page);
  const rows = h.deletablePassengerRows(page);
  const firstName = await h.passengerName(rows.nth(0));
  const secondName = await h.passengerName(rows.nth(1));
  await rows.nth(0).getByRole('checkbox').check();
  await rows.nth(1).getByRole('checkbox').check();
  await h.clickNamed(page, 'Batch deletion');
  await h.expectDialog(page, 'Are you sure you want to delete the selected passengers?');
  await page.getByRole('button', { name: 'Confirm', exact: true }).click();
  await h.expectSuccessFeedback(page);
  await expect(page.getByRole('cell', { name: firstName, exact: true })).toHaveCount(0);
  await expect(page.getByRole('cell', { name: secondName, exact: true })).toHaveCount(0);
});

test('REQ-4.4.9: Cancel batch deletion of selected passengers', async ({ page }) => {
  await h.openMyPassengers(page);
  const rows = h.deletablePassengerRows(page);
  const firstName = await h.passengerName(rows.nth(0));
  const secondName = await h.passengerName(rows.nth(1));
  await rows.nth(0).getByRole('checkbox').check();
  await rows.nth(1).getByRole('checkbox').check();
  await h.clickNamed(page, 'Batch deletion');
  await h.expectDialog(page, 'Are you sure you want to delete the selected passengers?');
  await page.getByRole('button', { name: 'Cancel', exact: true }).last().click();
  await expect(page.getByRole('cell', { name: firstName, exact: true })).toBeVisible();
  await expect(page.getByRole('cell', { name: secondName, exact: true })).toBeVisible();
});
